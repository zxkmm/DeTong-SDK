#ifndef __LABEL_PRINT_API_H_
#define __LABEL_PRINT_API_H_

#include <vector>
#include <string>
#include <map>
#include "lpapi.h"

using namespace std;

class LabelPrintAPI
{
private:
    // 静态单实例的生命
    static LabelPrintAPI s_instance;
    /**
     * @brief 设置日志文件名称。
     * 不同工程有不同的日志文件，否则不同软件之间会有影响。
     */
    static void setLogFile(const char *logFile);
    /**
     * @brief 关闭日志文件。
     */
    static void closeLogFile();
    //
    dzptr_result mLastError = LPA_OK;

private:
    LabelPrintAPI();
    ~LabelPrintAPI();
    LabelPrintAPI(const LabelPrintAPI &rhs) = default;
    LabelPrintAPI &operator=(const LabelPrintAPI &rhs);
    //
    // inline AtBitmap *bmp();

public:
    /**
     * 获取接口单实例指针。
     */
    static LabelPrintAPI *getApi(const char *logFile = nullptr);

public:
    //
    dzptr_result getLastError() { return mLastError; }
    //=============================================//
    // 打印相关接口；
    //=============================================//
    /**
     * 设备异步搜索毁掉函数。
     */
    void discovery(dzptr_discovered_device_t discovered_device_cb, void *user_data = nullptr);
    /**
     * 设备同步搜索回调函数，搜索过程会阻塞当前线程。
     */
    void syncDiscovery(dzptr_discovered_device_t discovered_device_cb, void *user_data = nullptr);
    /**
     * 停止设备搜索操作，可以在搜索到目标设备后，调用该函数，不再继续搜索。
     */
    void stopDiscovery();
    /**
     * 获取打印机列表；
     */
    vector<dzptr_device *> getPrinters(const string &names = "", bool onlyUsb = false, bool onlyBluetooth = false);
    /**
     * 打开指定名称或者型号的打印机。
     *
     * @param {string} printerName 目标打印机名称/型号/地址
     */
    bool openPrinter(const string &printerName = "");
    /**
     * 判断是否已经连接打印机；
     */
    bool isPrinterOpened();

    /**
     * 获取打印机相关信息。
     */
    bool getPrinterInfo(LPA_PRINTER_INFO &info);
    /**
     * 如果打印机一连接则获取一连接的打印机名称；
     */
    string getPrinterName();
    /**
     * 关闭已连接的打印机；
     */
    void closePrinter();
    /**
     * 释放所有相关资源，个别框架中(Python扩展)退出主程序的时候无法释放子线程。
     */
    void quit();
    /**
     * 获取打印参数。
     */
    bool getPrintParam(dzptr_ppid paramId, int &paramValue);
    /**
     * 设置打印参数。
     */
    bool setPrintParam(dzptr_ppid paramId, int paramValue);
    /**
     * 获取当前链接打印机的分辨率，打印机链接成功之后生效。
     */
    int getPrinterDPI();
    /**
     * 恢复默认打印参数。
     */
    bool resetPrintParam();
    /**
     * 直接打印给定的图片文件。
     */
    bool printImage(const string &fileName, const string printerName = "", const map<dzptr_ppid, int> *printParam = nullptr);
    /**
     * @brief 打印给定的数据流。
     */
    bool printImageStream(const void *stream, int len, const string printerName = "", const map<dzptr_ppid, int> *printParam = nullptr);
    /**
     * 直接打印json字符串。
     */
    bool printJson(const char *content, int action = dzptr_action_print);
    // /**
    //  * 打印wdfx格式字符串。
    //  */
    // bool printWdfx(const char *content);

    //=============================================//
    // 绘制相关接口；
    //=============================================//
    /**
     * 根据给定的参数，创建一个打印任务；
     *
     * @param {double} width 标签宽度，单位毫米；
     * @param {double} height 标签高度，单位毫米；
     * @param {int} orientation 标签旋转角度；
     *              0  ：表示不旋转
     *              90 ：表示右转90度
     *              180：表示180度旋转
     *              270：表示左传90度
     * @param {string} jobName，打印任务名称，默认是"LPAPI“；
     *
     * @return {bool} 成功与否。
     */
    bool startJob(double width, double height, int orientation, const string &jobName = "LPAPI", int scaleUnit = dzptr_psu_mm);
    /**
     * 取消打印任务，如果当前还有未打印的数据，数据将会被丢弃。
     */
    void abortJob();
    /**
     * 开始一个打印页面；
     *
     * @return {bool} 成功与否。
     */
    bool startPage();
    /**
     * 结束当前打印页面；
     *
     * @return {bool} 成功与否。
     */
    bool endPage();
    /**
     * 结束打印任务；
     *
     * @return {bool} 成功与否。
     */
    bool endJob();
    /**
     * 提交打印任务，开始打印操作；
     *
     * @return {bool} 成功与否。
     */
    bool commitJob();
    /**
     * 提交打印任务，开始打印操作；
     *
     * @return {bool} 成功与否。
     */
    bool commitJob(map<dzptr_ppid, int> *printParam);
    /**
     * @brief 获取标签页面相关信息。
     *
     * @param info 页面相关信息
     * @return int 处理相关结果信息。
     */
    bool getPageInfo(LPA_PAGE_INFO *info);
    /**
     * @brief 获取指定的图片或者所需要内存大小。
     *
     * @param page 目标索引。
     * @param format 需要返回的图片的格式。
     * @param data 返回的图片数据。
     * @return true 相关数据获取成功。
     * @return false 数据获取失败。
     */
    bool getPageImage(int page, int format, void *data, int *dLen);

    // 设置相关绘制参数

    /**
     * 获取相关图形绘制参数；
     */
    bool getDrawParam(const int id, void *value, const int len = 0);
    /**
     * 设置后续相关绘制参数；
     */
    bool setDrawParam(const int id, const void *value);
    // /**
    //  * 通过字符串KEY值设置绘制参数;
    //  */
    // bool setDrawParam(const char *key, const void *value);
    /**
     * 备份当前绘制参数。
     */
    void saveDrawParam();
    /**
     * 恢复上次备份过的相关绘制参数。
     */
    void restoreDrawParam();
    /**
     * 设置自体名称，默认为黑体。
     */
    bool setFontName(const string &fontName);
    bool setFontSize(const double fontSize);
    bool setFontStyle(const int fontStyle);
    /**
     * 设置后续动作的旋转角度；
     * @param rotate 旋转角度。参数描述如下：
     *          0：不旋转；
     *          90：顺时针旋转90度；
     *          180：旋转180度；
     *          270：逆时针旋转90度。
     */
    void setItemOrientation(int rotate);
    /**
     * 获取后续动作的旋转角度。
     */
    int getItemOrientation();
    /**
     * 设置后续动作的水平对齐方式；
     * @param align 对齐方式，值如下所示：
     *      0： 水平居左
     *      1： 水平居中
     *      2： 水平居右
     *      3： 水平拉伸
     */
    void setItemHorizontalAlignment(int align);
    /**
     * 获取后续动作的水平对齐方式。
     */
    int getItemHorizontalAlignment();
    /**
     * 设置后续动作的垂直对齐方式。
     * @param align 对齐方式，值如下：
     *      0： 垂直局上
     *      1： 垂直居中
     *      2： 垂直局上
     *      3： 垂直拉伸
     */
    void setItemVerticalAlignment(int align);
    /**
     * 获取后续打印动作的垂直对其方式。
     */
    int getItemVerticalAlignment();
    /**
     * 设置一维码中字符串的对其方式。
     */
    void setB1DTextAlignment(int align);
    /**
     * 获取当前一维码中字符串的对其方式。
     */
    int getB1DTextAlignment();
    /**
     * 设置打印任务的北京颜色；
     */
    void setBackground(int color);

    // 在画板上绘制相关对象

    /**
     * 绘制字符串操作。
     *
     * @param {string} text 绘制的目标数据；
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} fontHeight 绘制内容的字体大小，单位毫米；
     * @param {int} fontStyle 绘制内容的字体样式，单位毫米；
     *
     * @return {bool} 成功与否。如果不能正常显示，通常是因为参数错误造成的。
     */
    bool drawText(const string &text, double x = 0, double y = 0, double width = 0, double height = 0, double fontHeight = 0, int fontStyle = 0);
    /**
     * 绘制一维码。
     * 在一维码宽度不是足够大的情况下，为了保证扫码正常，一维码宽度会根据最小的一维码宽度进行取整操作，所以会出现两边留白比较多的情况。
     * 建议在字符串比较长的情况下，一维码的宽度尽量设置的比较大一点。
     *
     * @param {string} text 一维码显示内容；
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} textHeight 一维码下面字符串显示的高度，默认为0，表示不现实一维码字符串，单位毫米；
     * @param {int} type 一维码类型；
     *
     * @return {bool} 成功与否。
     */
    bool drawBarcode(const string &text, double x = 0, double y = 0, double width = 0, double height = 0, double textHeight = 0, LPA_BarcodeType type = 0);
    /**
     * 绘制二维码。
     *
     * @param {string} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} type 二维码类型； 0：QRCode, 1：PDF417, 2：DataMatrix, 3：GridMatrix;
     * @param {int} eccLevel 二维码纠错级别，不同类型的二维码纠错级别不一样;
     *
     * @return {bool} 成功与否。
     */
    bool draw2DBarcode(const string &text, double x = 0, double y = 0, double width = 0, double height = 0, int type = 0, int eccLevel = -1);
    /**
     * 绘制QRCode二维码。
     *
     * @param {string} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} eccLevel 二维码纠错级别； 0：L, 1：M, 2：Q, 3：H;
     *
     * @return {bool} 成功与否。
     */
    bool drawQrcode(const string &text, double x = 0, double y = 0, double width = 0, double height = 0, int eccLevel = -1);
    /**
     * 绘制PDF417二维码
     *
     * @param {string} text 要绘制的PDF417二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} eccLevel 二维码纠错级别；
     *
     * @return {bool} 成功与否。
     */
    bool drawPdf417(const string &text, double x = 0, double y = 0, double width = 0, double height = 0, int eccLevel = -1);
    /**
     * 绘制DataMatrix二维码。
     *
     * @param {string} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} eccLevel 二维码纠错级别；
     *
     * @return {bool} 成功与否。
     */
    bool drawDataMatrix(const string &text, double x = 0, double y = 0, double width = 0, double height = 0, int eccLevel = -1);

    /**
     * 绘制矩形框。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} lineWidth 所绘矩形框的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool drawRect(double x, double y, double width, double height = 0, double lineWidth = 0);
    /**
     * 绘制填充矩形。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool fillRect(double x, double y, double width, double height = 0);
    /**
     * 绘制圆角矩形框。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} cornerRadius 所绘圆角矩形的圆角半径，单位毫米；
     * @param {double} lineWidth 所绘圆角矩形的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool drawRoundRect(double x, double y, double width, double height = 0, double cornerRadius = 0, double lineWidth = 0);
    /**
     * 绘制填充圆角矩形。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} cornerRadius 所绘圆角矩形的圆角半径，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool fillRoundRect(double x, double y, double width, double height = 0, double cornerRadius = 0);
    /**
     * 绘制椭圆边框。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} lineWidth 所绘椭圆的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool drawEllipse(double x, double y, double width, double height = 0, double lineWidth = 0);
    /**
     * 绘制填充椭圆。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool fillEllipse(double x, double y, double width, double height = 0);
    /**
     * 绘制圆形。
     *
     * @param {double} x 所绘圆的中心点在水平方向上的开始位置，单位毫米；
     * @param {double} y 所绘圆的中心点在垂直方向上的开始位置，单位毫米；
     * @param {double} radius 所绘圆的半径，单位毫米；
     * @param {double} lineWidth 所绘圆的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool drawCircle(double x, double y, double radius, double lineWidth = 0);
    /**
     * 绘制填充圆形。
     *
     * @param {double} x 所绘圆的中心点在水平方向上的开始位置，单位毫米；
     * @param {double} y 所绘圆的中心点在垂直方向上的开始位置，单位毫米；
     * @param {double} radius 所绘圆的半径，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool fillCircle(double x, double y, double radius);
    /**
     * 绘制直线。
     *
     * @param {double} x1 所绘直线在水平方向上的开始位置，单位毫米；
     * @param {double} y1 所绘直线在垂直方向上的开始位置，单位毫米；
     * @param {double} x1 所绘直线在水平方向上的结束位置，单位毫米；
     * @param {double} y1 所绘直线在垂直方向上的结束位置，单位毫米；
     * @param {double} lineWidth 绘制直线线条的宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool drawLine(double x1, double y1, double x2, double y2 = 0, double lineWidth = 0);
    /**
     * 绘制虚线。
     *
     * @param {double} x1 所绘虚线在水平方向上的开始位置，单位毫米；
     * @param {double} y1 所绘虚线在垂直方向上的开始位置，单位毫米；
     * @param {double} x1 所绘虚线在水平方向上的结束位置，单位毫米；
     * @param {double} y1 所绘虚线在垂直方向上的结束位置，单位毫米；
     * @param {double} lineWidth 绘制虚线线条的宽度，单位毫米；
     * @param {vector<double>} dashLens 所绘虚线虚实线线段长度列表，向量长度最小为1，不能为空，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    bool drawDashLine(double x1, double y1, double x2, double y2 = 0, double lineWidth = 0, const vector<double> &dashLens = {1});
    /**
     * 绘制图片。
     * （未实现）
     *
     * @param {string} url 所绘图片的url路径；
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} threshold 图片转换为黑白色进行打印时的黑白阈值， 默认为0，不进行黑白转换，255：表示灰度处理，1-254表示黑白转换；
     *
     * @return {bool} 成功与否。
     */
    bool drawImage(const string &url, double x = 0, double y = 0, double width = 0, double height = 0, int threshold = 0);
};

#endif // __LABEL_PRINT_API_H_
