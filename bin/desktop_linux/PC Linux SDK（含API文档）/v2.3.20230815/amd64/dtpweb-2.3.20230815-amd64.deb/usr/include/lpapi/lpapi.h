#ifndef __LPAPI__C__H__
#define __LPAPI__C__H__

#include "dzptr.h"

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

    /*=========================================================================================
     *=====                                lpapi 属性类型                                =======
     *=========================================================================================*/

    /*********************************************
     * @brief lpapi 绘制相关参数对应的ID;
     *********************************************/
    enum lpapi_draw_param_id
    {
        LPA_DPID_NONE = 0,
        /**
         * 内容水平对齐方向
         */
        LPA_DPID_ITEM_ALIGN_HOR,
        /**
         * 内容垂直对齐方向
         */
        LPA_DPID_ITEM_ALIGN_VER,
        /**
         * 内容旋转角度
         */
        LPA_DPID_ITEM_ROTATION,
        /**
         * QRCode默认一个点的像素数（在指定的宽高无效的情况下，默认一个点占用几个像素数），默认为2。
         */
        LPA_DPID_CODE_PIXELS,
        /**
         * QRCode 的纠错级别（0～3），值为 Integer。默认为 ErrorCorrectionLevel.L。
         */
        LPA_DPID_QRCODE_ECCLEVEL,
        /**
         * QRCode 的编码版本号（1～40），值为 Integer。未指定时表示根据编码内容自动采用适合的编码版本号。
         */
        LPA_DPID_QRCODE_VERSION,
        /**
         * 条码的留白，值为 Integer。对于 QRCode，规范中定义的留白值为 0/2/4。默认是 0，也即不留白。
         */
        LPA_DPID_QRCODE_MARGIN,
        /**
         * QRCode 的字符串编码类型，值为 String。默认为 UTF-8。
         */
        LPA_DPID_CHARACTER_SET,
        /**
         * 设置默认一维码类型，默认为code128.
         */
        LPA_DPID_B1D_TYPE,
        /**
         * 设置一维码字符串对齐方式，默认剧中对齐
         */
        LPA_DPID_B1D_TEXT_ALIGN,
        /**
         * 设置一维码字符串高度
         */
        LPA_DPID_B1D_TEXT_HEIGHT,
        /**
         * PDF417CODE 的纠错级别（0～8），值为 Integer。默认为 ErrorCorrectionLevel.L。
         */
        LPA_DPID_B2D_P417_ECCLEVEL,
        /**
         * PDF417Cols PDF417二维码模组个数（未指定宽度和高度的情况下使用），默认为1。
         */
        LPA_DPID_B2D_P417_COLS,
        /**
         * DataMatrix 二维码形状，值：0: Auto, 1: Square, 2: Rectangle。
         */
        LPA_DPID_B2D_DM_CODE_SHAPE,
        /**
         * DataMatrix 二维码尺寸，值为：1 - 48, 0：表示自动；
         */
        LPA_DPID_B2D_DM_CODE_SIZE,
        /**
         * DMRE: 矩形码中的一些扩展码。
         */
        LPA_DPID_B2D_DM_DMRE,
        /**
         * 文字反色，值为Boolean。默认是false，即文字不反色。
         */
        LPA_DPID_ANTI_COLOR,
        /**
         * 设置绘制线条/矢量图外边框时的默认边框大小。
         */
        LPA_DPID_LINE_WIDTH,
        /**
         * 默认圆半径
         */
        LPA_DPID_ARC_RADIUS,
        /**
         * 字体名称
         */
        LPA_DPID_FONT_NAME,
        /**
         * 自体高度，默认3.5mm
         */
        LPA_DPID_FONT_HEIGHT,
        /**
         * 自体样式，默认为0,表示常规字体。
         */
        LPA_DPID_FONT_STYLE,
        /**
         * 字体换行，值为Boolean。默认是true，即文本自动换行。
         */
        LPA_DPID_FONT_WRAP,
        /**
         * 空间不够时是否需要进行自动缩放操作
         */
        LPA_DPID_FONT_SHRINK,
    };
    /*********************************************************************
     * @brief       打印动作的对齐方式。
     **********************************************************************/
    enum lpapi_item_alignment
    {
        LPA_IA_Near = 0, ///< 水平居左/垂直居上
        LPA_IA_Center,   ///< 水平居中/垂直居中
        LPA_IA_Far,      ///< 水平居右/垂直居下
        LPA_IA_Stretch,  ///< 水平拉伸/垂直拉伸

        LPA_IA_SameAsItem, ///< 对象子元素的对齐方式同对象的对齐方式，
                           ///< 当前在一维码文本的水平对齐方式中使用

        LPA_IA_Left = LPA_IA_Near, ///< 水平居左
        LPA_IA_Right = LPA_IA_Far, ///< 水平居右

        LPA_IA_Top = LPA_IA_Near,      ///< 垂直居上
        LPA_IA_Middle = LPA_IA_Center, ///< 垂直居中
        LPA_IA_Bottom = LPA_IA_Far,    ///< 垂直居下
    };

    /*********************************************************************
     * @brief       字体风格。
     **********************************************************************/
    enum lpapi_font_style
    {
        LPA_FS_Regular = 0,    ///< 一般
        LPA_FS_Bold = 1,       ///< 粗体
        LPA_FS_Italic = 2,     ///< 斜体
        LPA_FS_BoldItalic = 3, ///< 粗斜体
        LPA_FS_Underline = 4,  ///< 下划线
        LPA_FS_Strikeout = 8,  ///< 删除线
    };

    /*********************************************************************
     * @brief       一维条码编码类型。
     **********************************************************************/
    enum lpapi_barcode_type
    {
        ///< UPC-A, UPC-E, EAN13, EAN8, ISBN 统称为商品码，编码和显示方式类似；
        ///< 只能包含数字，对于支持两段的方式的编码，使用“+”来作为前后两段的分隔；
        ///< 都有校验字符，一般为0～9。对于 ISBN 编码，其校验字符可能为“X”。
        LPA_1DBT_UPC_A = 20, ///< 支持长度为：12、12+2、12+5，显示为 1+5+5+1
                             ///< 输入长度为 12：表示已经有校验码；
                             ///<           11：没有校验码，程序会自动添加；
                             ///<         < 11：加上前导零，然后自动添加校验码；
        LPA_1DBT_UPC_E,      ///< 支持长度为：8、8+2、8+5，显示为1+6+1。其中第一位是编码数字类型，只
                             ///< 能为0/1，表示采用的数字系统；第八位是校验位，采用 upc_check() 进行校验。
                             ///< 输入长度为 8：表示已经有校验码，如果第一个字符不是0/1，则强制换成0来处理；
                             ///<           7：没有校验码，程序会自动添加。如果第一个字符不是0/1，则强制换成0来处理；
                             ///<           6：没有校验码，程序会自动添加。同时采用数字系统 0 来进行编码。
                             ///<         < 6：加上前导 0 到长度为 6 之后，再进行编码。
        LPA_1DBT_EAN13,      ///< 支持长度为：13、13+2、13+5、8、8+2、8+5、5、2。
                             ///< 输入长度为 13：表示已经有校验码；
                             ///<           12：没有校验码，程序会自动添加；
                             ///<         6~11：加上前导零之后，当成长度为 12 的处理；
                             ///< 输入长度为 3/4/5：表示编码成长度为 5 的附加条码；
                             ///<             1/2：表示编码成长度为 2 的附加条码。
        LPA_1DBT_EAN8,       ///< 在内部和 EAN13 编码统一处理
                             ///< 输入长度为 8：表示已经有校验码；
                             ///< 输入长度大于 8 时，切换成 EAN13 码进行编码；
                             ///< 输入长度 <= 5 时，切换成 EAN13 码进行编码；
                             ///< 输入长度为 7：没有校验码，程序会自动添加；
                             ///<           6：加上前导零，然后自动添加校验码；
        LPA_1DBT_CODE39,     ///< 1、"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%"
                             ///< 2、以 * 为显示用引导和结束字符（编码中没有，仅仅显示用）
                             ///< 3、每个字符用10个编码（显示长度为13）
                             ///< 4、引导字符10个（显示长度为13），结束字符9个（显示长度12）
                             ///< ==》字符数为 10+ 9+10×N
                             ///<        显示长度 13+12+13×N
                             ///<        10个字符 13+12+13×10 = 155像素
                             ///< 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
        LPA_1DBT_ITF25,      ///< 1、0~9
                             ///< 2、加校验码之后长度必须是偶数，否则在头部加上 0
                             ///< 3、每个字符用5个编码（显示长度为 7）
                             ///< 4、引导字符 4 个（显示长度为 4），结尾字符 3 个（显示长度是 4）
                             ///< ==》字符数为 4 + 3 + 10*（N/2）
                             ///<        显示长度 4 + 4 + 14*（N/2）
                             ///<        10个字符 4+4+14×5 = 78像素
                             ///< 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
        LPA_1DBT_CODABAR,    ///< 1、"0123456789-$:/.+ABCD"，多应用于医疗领域
                             ///< 2、引导/结束字符 A～D，都会被转化为大写
                             ///< 3、加上引导字符/校验码之后，数据统一编码；
                             ///< 4、每个字符用8个编码（显示长度为 10～11）
                             ///< ==》字符数为 8×N，显示长度为 10×N～11×N
                             ///<        10个字符10×10 + 11×2 = 122像素
                             ///< 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
        LPA_1DBT_CODE93,     ///< 0x00～0x7F
                             ///< 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
        LPA_1DBT_CODE128,    ///< 0x00～0xFF，CODE 128 A/B 支持全字符，对于 CODE 128 C 编码：
                             ///< 1、有固定方式的校验码，都是数字，必须是偶数长度
                             ///< 2、引导字符 105，结束字符 106
                             ///< 3、条码宽度范围为1～4，每个字符用7个编码（显示长度为11）
                             ///< ==》字符数为 7+7+7+7×（N/2）
                             ///<        显示长度 11+11+11+11×（N/2）
                             ///<        10个字符 11+11+11+11×（10/2）= 88像素
        LPA_1DBT_ISBN,       ///< 0~9，最后一位可能为 0~9, X（校验字符）
                             ///< 13：必须是 978/979 前导，用 EAN13 编码，isbn13_check
                             ///< 10：加上 978 前导之后，用 EAN13 编码，isbn_check
                             ///< <=9：加上 0 前导之后，Check，然后再加上 978 前导，用 EAN 13 编码
                             ///< 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
        LPA_1DBT_ECODE39,    ///< EXTENDED CODE 39，0x00～0x7F
                             ///< 对于 CODE 39 不支持的字符，采用转义之后，用两个字符来表示
                             ///< 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
        LPA_1DBT_AUTO = 60,  ///< 根据编码内容，自动选择最适合的编码类型进行编码。
                             ///< 1、ITF25（内容长度为偶数，并且全部为数字时）
                             ///< 2、CODABAR（如果内容以A/B/C/D开头，又以A/B/C/D结尾的话）
                             ///< 3、CODE 39
                             ///< 4、CODE 128
    };
    typedef int LPA_BarcodeType;

    /**
     * @brief 二维码类型，默认为0，表示生成QRCode类型的二维码；
     */
    enum lpapi_2dbarcode_type
    {
        LPA_2DBT_QRCODE = 0,
        LPA_2DBT_PDF417 = 1,
        LPA_2DBT_DMCODE = 2,
        LPA_2DBT_GMCODE = 3,
    };
    typedef int LPA_2DBarcodeType;
    /**
     * @brief DataMatrix 二维码形状
     */
    enum lpapi_dm_shape
    {
        LPA_DMSHAPE_AUTO = 0,
        LPA_DMSHAPE_SQUARE,
    };
    typedef int LPA_DM_SHAPE;
    /**
     * @brief 当前打印任务的PAGE信息。
     */
    typedef struct __LPA_PAGE_INFO
    {
        int width;
        int height;
        int orientation;
        int pages;
    } LPA_PAGE_INFO;

    /**********************************************************************
     * @brief       LabelPrintAPI 位图点阵数据格式。位图数据从上至下，从左至右。
     **********************************************************************/
    enum lpapi_source_image_format
    {
        LPASIF_RAWDATA = 0,    ///< 直接传递给打印机的原始打印数据。
                               ///<
        LPASIF_BPP_1 = 1,      ///< 每个点用一个比特位表示的黑白点阵数据，1 表示黑点（需要打印），0 表示白点。
                               ///< 数据从上至下按照行来存放，每行需要的字节数为 (width + 7) / 8。
                               ///< 每个字节表示 8 个点，高位表示左边的点，低位表示右边的点。
        LPASIF_BPP_1N = 2,     ///< 同 LPASIF_BPP_1，只是 0 表示黑点（需要打印），1 表示白点。
                               ///<
        LPASIF_32_RGBA = 32,   ///< 每个点用四个字节表示的点阵数据，四个字节依次表示 RGBA。
        LPASIF_32_BGRA = 33,   ///< 每个点用四个字节表示的点阵数据，四个字节依次表示 BGRA。
        LPASIF_32_RGB = 34,    ///< 每个点用四个字节表示的点阵数据，四个字节依次表示 RGB，最高字节未使用。
        LPASIF_32_BGR = 35,    ///< 每个点用四个字节表示的点阵数据，四个字节依次表示 BGR，最高字节未使用。
                               ///<
        LPASIF_PACKAGE = 90,   ///< 简易报文格式的点阵数据，1 表示黑点（需要打印），0 表示白点，对于标签打印而言，压缩效率还是不错的。
                               ///< 打印行：Ax 前导零字节数 打印字节数 xxxxxx
                               ///<        首字节的4个比特，给前导零用2位，给打印字节用2位，也就是说打印数据最多为1K字节，8K个点。
                               ///< 打印行：B0 xxxxxx
                               ///<        打印字节数等于点阵数据的行字节数，(width + 7) / 8。
                               ///< 重复行：Bx
                               ///<        首字节的4个比特，给行数使用，也就是说行数最大值为 15。
                               ///< 空白行：110xxxxx（也即 Cx/Dx）
                               ///<        首字节的5个比特，给行数使用，也就是说行数最大值为 31。
        LPASIF_IMAGEDATA = 93, ///< 图片文件数据，支持 PNG/JPG/BMP 等几乎所有常见图片文件格式。
                               ///< 如果图片文件数据采用 Base64 编码（通过设置 dLen = 0 实现），则会自动过滤字符串开始的诸如
                               ///< “data:image/png;base64,”的头部字符串，这种头部字符串一般在 JS 中被广泛使用，用于指示图片
                               ///< 数据格式。接口会自动查找头部的部分字符，一直找到“,”为止。如果没有找到“,”，则数据从头开始。
    };
    /**********************************************************************
     * @brief       LabelPrintAPI 预览用图片数据格式。
     **********************************************************************/
    enum lpapi_target_image_format
    {
        LPATIF_32_RGBA = 32,     ///< 两个字节表示宽度，两个字节表示高度，都是高字节在前面。后面跟着点阵数据，
                                 ///< 每个点用四个字节表示的点阵数据，四个字节依次表示 RGBA。
        LPATIF_32_BGRA = 33,     ///< 两个字节表示宽度，两个字节表示高度，都是高字节在前面。后面跟着点阵数据，
                                 ///< 每个点用四个字节表示的点阵数据，四个字节依次表示 BGRA。
        LPATIF_BASE64P_PNG = 95, ///< PNG 图片文件的BASE64编码，同时加上了 “data:image/png;base64,”前缀，
                                 ///< 因此返回的字符串可以直接赋值给 HTML 对象的 src 属性，进行图片预览。
        LPATIF_BASE64_PNG = 96,  ///< PNG 图片文件二进制内容的BASE64编码。
        LPATIF_RAWDATA_PNG = 97, ///< PNG 图片文件的二进制内容。
    };

    /*=======================================================================================
     *======                         LPAPI 相关接口函数                                ========
     *=======================================================================================*/

    /**
     * 接口初始化操作，建议在程序启动的时候调用下该函数。
     */
    void lpapi_init(const char *logFile);
    /**
     * 设备异步搜索回调函数。
     */
    void lpapi_discovery(dzptr_discovered_device_t discovered_device_cb);
    /**
     * 设备同步搜索毁掉函数，搜索过程中会阻塞当前线程。
     */
    void lpapi_discovery_sync(dzptr_discovered_device_t discovered_device_cb);
    /**
     * 停止打印设备搜索操作。
     */
    void lpapi_stop_discovery();
    /**
     * 获取打印机列表；
     * @param devices 打印机设备指针数组。
     * @param count 设备指针数组长度。
     * @param module 只获取制定型号的打印机。
     * @return 获取到的打印机设备个数。
     */
    int lpapi_get_printers(dzptr_device **devices, int count, const char *module);
    /**
     * 打开指定的打印机；
     */
    int lpapi_open_printer(const char *printer);
    /**
     * 判断是否已经连接打印机；
     */
    int lpapi_is_printer_opened();
    /**
     * 如果打印机一连接则获取一连接的打印机名称；
     */
    int lpapi_get_printer_name(char *name, int count);
    /**
     * 获取打印机信息。
     * @param info 打印机信息结构体指针。
     * @return 0：表示打印机信息获取成功，非0表示获取失败。
     */
    int lpapi_get_printer_info(LPA_PRINTER_INFO *info);
    /**
     * 关闭已连接的打印机；
     */
    void lpapi_close_printer();
    /**
     * 释放所有的资源，个别框架(Python扩展)无法释放子线程资源，此时需要借助于给函数进行资源的回收。
     */
    void lpapi_quit();
    /**
     * 获取指定的打印参数。
     */
    int lpapi_get_print_param(int id, int *value);
    /**
     * 设置打印参数。
     */
    int lpapi_set_print_param(int id, int value);
    /**
     * 获取打印机分辨率。
     * 
     * 注意：打印机分辨率只有在打印机打开之后才有效；
     */
    int lpapi_get_printer_dpi();
    /**
     * 重置打印参数。
     */
    int lpapi_reset_print_param();
    /**
     * 直接打印给定的图片文件。
     */
    int lpapi_print_image(const char *fileName, const char *printerName, const int threshold, const int orientation, const int copies);
    /**
     * 解析并打印给定的json格式的数据。
     */
    int lpapi_print_json(const char *json);
    // /**
    //  * 解析并打印wdfx格式的数据。
    //  */
    // int lpapi_print_wdfx(const char *data);
    //=============================================//
    // 绘制相关接口；
    //=============================================//
    /**
     * 根据给定的参数，创建一个打印任务；
     *
     * @param {double} width 标签宽度，单位毫米；
     * @param {double} height 标签高度，单位毫米；
     * @param {int} orientation 标签旋转角度；
     *              0  ：表示不旋转
     *              90 ：表示右转90度
     *              180：表示180度旋转
     *              270：表示左传90度
     * @param {char*} jobName，打印任务名称，默认是"LPAPI“；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_start_job(double width, double height, int orientation, const char *jobName);
    /**
     * 开始一个打印页面；
     */
    int lpapi_start_page();
    /**
     * 结束当前打印页面；
     */
    int lpapi_end_page();
    /**
     * 结束打印任务；
     */
    int lpapi_end_job();
    /**
     * 提交打印任务，开始打印操作；
     */
    int lpapi_commit_job();
    /**
     * @brief 提交打印任务，开始打印操作；
     *
     * @param threshold
     * @param orientation
     * @param copies
     * @param speed
     * @param darkness
     * @param gapType
     * @return int 返回状态。
     */
    int lpapi_commit_job_with_param(int threshold, int orientation, int copies, int speed, int darkness, int gapType);
    /**
     * @brief 获取当前打印任务的页面信息。
     *
     * @return int 函数处理状态。
     */
    int lpapi_get_page_info(LPA_PAGE_INFO *info);
    /**
     * @brief 获取制定页的图片数据。
     *
     * @param page 页面索引。
     * @param format 输出的图片格式。
     * @param data 输出的图片数据。
     * @param dLen 返回制定格式图片需要的数据长度。
     * @return int 函数处理状态。
     */
    int lpapi_get_page_image(int page, int format, void *buf, int *dLen);

    // 设置相关绘制参数

    /**
     * 获取绘制参数；
     */
    int lpapi_get_draw_param(int id, void *value, const int len);
    /**
     * 设置绘制参数；
     */
    int lpapi_set_draw_param(int id, const void *value);
    /**
     * 设置自体名称。
     */
    void lpapi_set_fontname(const char *fontName);
    /**
     * 设置后续动作的旋转角度；
     * @param rotate 旋转角度。参数描述如下：
     *          0：不旋转；
     *          90：顺时针旋转90度；
     *          180：旋转180度；
     *          270：逆时针旋转90度。
     */
    void lpapi_set_item_orientation(int rotate);
    /**
     * 获取后续动作的旋转角度。
     */
    int lpapi_get_item_orientation();
    /**
     * 设置后续动作的水平对齐方式；
     * @param align 对齐方式，值如下所示：
     *      0： 水平居左
     *      1： 水平居中
     *      2： 水平居右
     *      3： 水平拉伸
     */
    void lpapi_set_item_horizontal_alignment(int align);
    /**
     * 获取后续动作的水平对齐方式。
     */
    int lpapi_get_item_horizontal_alignment();
    /**
     * 设置后续动作的垂直对齐方式。
     * @param align 对齐方式，值如下：
     *      0： 垂直局上
     *      1： 垂直居中
     *      2： 垂直局上
     *      3： 垂直拉伸
     */
    void lpapi_set_item_vertical_alignment(int align);
    /**
     * 获取后续打印动作的垂直对其方式。
     */
    int lpapi_get_item_vertical_alignment();
    /**
     * 设置打印任务的北京颜色；
     */
    void lpapi_set_background(int color);

    // 在画板上绘制相关对象

    /**
     * 绘制字符串操作。
     *
     * @param {char*} text 绘制的目标数据；
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} fontHeight 绘制内容的字体大小，单位毫米；
     * @param {int} fontStyle 绘制内容的字体样式，单位毫米；
     *
     * @return {bool} 成功与否。如果不能正常显示，通常是因为参数错误造成的。
     */
    int lpapi_draw_text(const char *text, double x, double y, double width, double height, double fontHeight, int fontStyle);
    /**
     * 绘制一维码。
     *
     * 在一维码宽度不是足够大的情况下，为了保证扫码正常，一维码宽度会根据最小的一维码宽度进行取整操作，所以会出现两边留白比较多的情况，
     * 如果需要自动缩放的话，用户可以通过设置水平对齐方式为拉伸模式来进行自由缩放。
     * 建议在字符串比较长的情况下，一维码的宽度尽量设置的比较大一点。
     *
     * @param {char*} text 一维码显示内容；
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} textHeight 一维码下面字符串显示的高度，默认为0，表示不现实一维码字符串，单位毫米；
     * @param {int} type 一维码类型；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_barcode(const char *text, double x, double y, double width, double height, double textHeight, int type);
    /**
     * 绘制二维码。
     *
     * @param {char*} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} type 二维码类型；值参考： lpapi_2dbarcode_type
     * @param {int} eccLevel 二维码纠错级别；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_2dbarcode(const char *text, double x, double y, double width, double height, int type, int eccLevel);
    /**
     * 绘制二维码。
     *
     * @param {char*} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} eccLevel 二维码纠错级别；
     *                  0： L
     *                  1： M
     *                  2： Q
     *                  3： H
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_qrcode(const char *text, double x, double y, double width, double height, int eccLevel);
    /**
     * 绘制PDF417二维码
     *
     * @param {char*} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} eccLevel 二维码纠错级别，值为：[0, 8] 之间，默认为0，表示AUTO；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_pdf417(const char *text, double x, double y, double width, double height, int eccLevel);
    /**
     * 绘制DataMatrix二维码
     *
     * @param {char*} text 要绘制的二维码数据。
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} eccLevel 二维码纠错级别；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_datamatrix(const char *text, double x, double y, double width, double height, int eccLevel);
    /**
     * 绘制矩形框。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} lineWidth 所绘矩形框的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_rect(double x, double y, double width, double height, double lineWidth);
    /**
     * 绘制填充矩形。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_fill_rect(double x, double y, double width, double height);
    /**
     * 绘制圆角矩形框。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} cornerRadius 所绘圆角矩形的圆角半径，单位毫米；
     * @param {double} lineWidth 所绘圆角矩形的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_round_rect(double x, double y, double width, double height, double cornerRadius, double lineWidth);
    /**
     * 绘制填充圆角矩形。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} cornerRadius 所绘圆角矩形的圆角半径，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_fill_round_rect(double x, double y, double width, double height, double cornerRadius);
    /**
     * 绘制椭圆边框。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {double} lineWidth 所绘椭圆的边框宽度，单位毫米；
     */
    int lpapi_draw_ellipse(double x, double y, double width, double height, double lineWidth);
    /**
     * 绘制填充椭圆。
     *
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_fill_ellipse(double x, double y, double width, double height);
    /**
     * 绘制圆形。
     *
     * @param {double} x 所绘圆的中心点在水平方向上的开始位置，单位毫米；
     * @param {double} y 所绘圆的中心点在垂直方向上的开始位置，单位毫米；
     * @param {double} radius 所绘圆的半径，单位毫米；
     * @param {double} lineWidth 所绘圆的边框宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_circle(double x, double y, double radius, double lineWidth);
    /**
     * 绘制填充圆形。
     *
     * @param {double} x 所绘圆的中心点在水平方向上的开始位置，单位毫米；
     * @param {double} y 所绘圆的中心点在垂直方向上的开始位置，单位毫米；
     * @param {double} radius 所绘圆的半径，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_fill_circle(double x, double y, double radius);
    /**
     * 绘制直线。
     *
     * @param {double} x1 所绘直线在水平方向上的开始位置，单位毫米；
     * @param {double} y1 所绘直线在垂直方向上的开始位置，单位毫米；
     * @param {double} x1 所绘直线在水平方向上的结束位置，单位毫米；
     * @param {double} y1 所绘直线在垂直方向上的结束位置，单位毫米；
     * @param {double} lineWidth 绘制直线线条的宽度，单位毫米；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_line(double x1, double y1, double x2, double y2, double lineWidth);
    /**
     * 绘制虚线。
     *
     * @param {double} x1 所绘虚线在水平方向上的开始位置，单位毫米；
     * @param {double} y1 所绘虚线在垂直方向上的开始位置，单位毫米；
     * @param {double} x1 所绘虚线在水平方向上的结束位置，单位毫米；
     * @param {double} y1 所绘虚线在垂直方向上的结束位置，单位毫米；
     * @param {double} lineWidth 绘制虚线线条的宽度，单位毫米；
     * @param {double[]} dashLens 所绘虚线虚实线线段长度列表，向量长度最小为1，不能为空，单位毫米；
     * @param {int} dashCount 虚实线段的数组长度；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_dash_line(double x1, double y1, double x2, double y2, double lineWidth, const double dashLens[], int dashCount);
    /**
     * 绘制图片。
     * （未实现）
     *
     * @param {string} url 所绘图片的url路径；
     * @param {double} x 绘制内容在水平方向上的开始位置，单位毫米；
     * @param {double} y 绘制内容在垂直方向上的开始位置，单位毫米；
     * @param {double} width 绘制内容在水平方向上的显示宽度，单位毫米；
     * @param {double} height 绘制内容在垂直方向上的显示高度，单位毫米；
     * @param {int} threshold 图片转换为黑白色进行打印时的黑白阈值， 默认为0，不进行黑白转换，255：表示灰度处理，1-254表示黑白转换；
     *
     * @return {bool} 成功与否。
     */
    int lpapi_draw_image(const char *url, double x, double y, double width, double height, int threshold);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // __LPAPI__C__H__
