
#ifndef __DZPTR__C__H__
#define __DZPTR__C__H__

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

    enum dzptr_device_type
    {
        /**
         * USB打印机设备
         */
        dzptr_devtype_usb = 1,
        /**
         * 蓝牙SPP打印机设备
         */
        dzptr_devtype_spp,
        /**
         * 蓝牙BLE打印机设备
         */
        dzptr_devtype_ble
    };
    enum dzptr_scale_unit
    {
        dzptr_psu_pixel, ///< 像素
        dzptr_psu_01mm,  ///< 0.01 毫米
        dzptr_psu_mm,    ///< 毫米
    };
    enum dzptr_action
    {
        dzptr_action_get_bin = 0x0001,          // 返回打印用二进制数据；
        dzptr_action_get_base64 = 0x0002,       // 返回 BASE64 编码的预览用图片数据，包含“data:image/png;base64,”前缀；
        dzptr_action_get_url = 0x0004,          // 返回预览用图片网址，如 https://d6688.cn/f/f?key=xxx；
        dzptr_action_get_base64_trans = 0x0080, // 返回 BASE64 编码的预览用图片数据, 图片数据的生成使用透明底色，否则使用白色底色；
        dzptr_action_print = 0x1000             // 直接打印到本机的打印机，需要在 printerInfo 参数中提供 printerName 参数
    };
    /**
     * 可打印设备
     */
    typedef struct __dzptr_device
    {
        /**
         * 打印机设备名称；
         */
        char deviceName[32];
        /**
         * 打印机设备地址（USB文件全路径或者蓝牙MAC地址）
         */
        char address[32];
        /**
         * 打印机设备类型
         */
        int addressType;
    } dzptr_device;

    /**
     * 设备搜索回调函数。
     */
    typedef void (*dzptr_discovered_device_t)(dzptr_device *dev, void *user_data);

    /**********************************************************************
     * @brief       打印参数ID，GetParam() SetParam() 中使用。
     **********************************************************************/
    enum dzptr_ppid
    {
        // 前三种类型值不能变，保持跟PC端一致。
        dzptr_ppid_gap_type = 0x01,        ///< 纸张间隔
        dzptr_ppid_darkness = 0x02,        ///< 打印浓度
        dzptr_ppid_speed = 0x03,           ///< 打印速度
                                           ///<
                                           ///< 下面相关类型在PC中不支持，值可以随便调整。
                                           ///<
        dzptr_ppid_direction = 0x04,       ///< 打印方向
        dzptr_ppid_copies = 0x05,          ///< 打印份数
        dzptr_ppid_gap_length = 0x06,      ///< 纸张间隔长度
                                           ///<
                                           ///< 当打印数据宽度超过打印头宽度时的数据对齐方式，未指定时根据打印机装纸方式来，比方说 DP23/DT60 是向右。
                                           ///< 当打印数据宽度没有超过打印头宽度时，该参数无效。其取值为 PrintParamValue.PRINT_ALIGNMENT_xxx
                                           ///<
        dzptr_ppid_alignment = 0x08,       ///< 打印任务的对齐方式
        dzptr_ppid_anti_color = 0x09,      ///< 反色打印
                                           ///<
        dzptr_ppid_offset_hor = 0x10,      ///<
        dzptr_ppid_offset_ver = 0x12,      ///<
                                           ///<
        dzptr_ppid_margin_left = 0x20,     ///<
        dzptr_ppid_margin_right = 0x22,    ///<
        dzptr_ppid_margin_top = 0x24,      ///<
        dzptr_ppid_margin_bottom = 0x26,   ///<
                                           ///<
        dzptr_ppid_image_threshold = 0x30, ///<
    };

    /*********************************************************************
     * @brief       纸张间隔类型。
     **********************************************************************/
    enum dzptr_ppvalue_gap_type
    {
        dzptr_ppvalue_gap_unset = 255, ///< 随打印机
        dzptr_ppvalue_gap_none = 0,    ///< 连续纸，没有分隔
        dzptr_ppvalue_gap_hole,        ///< 定位孔
        dzptr_ppvalue_gap_gap,         ///< 间隙纸
        dzptr_ppvalue_gap_black,       ///< 黑标纸
    };
    enum dzptr_ppvalue_darkness
    {
        dzptr_ppvalue_darkness_min = 0,
        dzptr_ppvalue_darkness_default = 5,
        dzptr_ppvalue_darkness_max = 14,
    };
    enum dzptr_ppvalue_speed
    {
        dzptr_ppvalue_speed_min = 0,
        dzptr_ppvalue_speed_default = 2,
        dzptr_ppvalue_speed_max = 4,
    };

    /***************************************************
     * 打印机信息
     **************************************************/
    typedef struct __lpapi_printer_info
    {
        int deviceType;           // DEVICE_TYPE_xxx，热敏打印机/热转印打印机等等
        char deviceName[32];      // 设备名称，包括型号和序列号
        char deviceVersion[32];   // 硬件版本号
        char softwareVersion[32]; // 软件版本号
        char deviceAddress[32];   // MAC 地址
        int deviceAddrType;       // BLE/SPP/WiFi 等
        int deviceDPI;            // 打印精度，DPI
        int deviceWidth;          // 打印宽度，mm
        //
        char manufacturer[32]; // 厂商名称
        char seriesName[32];   // 产品系列名称，如 DT20
        char devIntName[32];   // 内部型号名称，如 DT20S
        int peripheralFlags;   // 配件标志
        int hardwareFlags;     // 硬件标志，使用该值匹配不同的固件升级包
        int softwareFlags;     // 软件标志
    } LPA_PRINTER_INFO;

    /**********************************************************************
     * @brief       DzPrinter 接口返回值。
     **********************************************************************/
    enum dzptr_result
    {
        LPA_OK = 0,                     ///< 成功。
        LPA_ERROR_UNKOWN = 1,           ///< 未知错误。
        LPA_ERROR_PARAM,                ///< 函数参数错误。
        LPA_ERROR_SYSTEM,               ///< 系统错误，如创建 Windows 对象失败、内存不足等。
        LPA_ERROR_IO,                   ///< 数据读写错误。
        LPA_ERROR_INVALID_FILE,         ///< 无效的图片文件。
        LPA_ERROR_NO_PRINTER = 0x10,    ///< 为检测到打印机。
        LPA_ERROR_PRINTER_UNSUPPORTED,  ///< 不支持的打印机。
        LPA_ERROR_PRINTER_OPEN_TIMEOUT, ///< 打印机连接超时。
        LPA_ERROR_PRINTER_OPEN_FAILED,  //< 打印机打开失败。
        LPA_ERROR_PRINTER_NOT_OPENED,   ///< 打印机未连接。
        LPA_ERROR_NO_PRINTDATA,         ///< 没有需要打印的数据。
        LPA_ERROR_NO_JOB,               ///< 没有打印任务。
        LPA_ERROR_NOT_IMPLEMENT,        ///< 为实现的接口。
        //
        LPA_ERROR_PRINT_VolTooLow,        // 打印电压太低了
        LPA_ERROR_PRINT_VolTooHigh,       // 打印电压太高了
        LPA_ERROR_PRINT_TphNotFound,      // 没有检测到打印头
        LPA_ERROR_PRINT_TphTooHot,        // 打印头温度太高了
        LPA_ERROR_PRINT_TphTooCold,       // 环境温度过低
        LPA_ERROR_PRINT_TphOpened,        // 碳带盒未锁紧
        LPA_ERROR_PRINT_LabelCanOpend,    // 标签盒未锁紧
        LPA_ERROR_PRINT_CoverOpened,      // 纸仓盒盖被打开
        LPA_ERROR_PRINT_No_Paper,         // 未检测到纸张
        LPA_ERROR_PRINT_No_Ribbon,        // 未检测到碳带
        LPA_ERROR_PRINT_Unmatched_Ribbon, // 不匹配的碳带
        LPA_ERROR_PRINT_Usedup_Ribbon,    // 用完的碳带
        LPA_ERROR_PRINT_Usedup_Ribbon2,   // 用完的色带
        LPA_ERROR_PRINT_Cancelled,        // 打印任务被取消
        LPA_ERROR_PRINT_Disconnected,     // 断开连接
        LPA_ERROR_PRINT_Timeout,          // 超时错误
        LPA_ERROR_PRINT_Other             // 其它未知错误
    };

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // __DZPTR__C__H__
