# dtpweb python interface

__title__ = 'dtpweb'
__version__ = '2.3.2023.801'
__author__ = 'DothanTech'
__author_email__ = 'hudianxing@dothantech.com'
__copyright__ = 'Copyright 2023 DothanTech'
