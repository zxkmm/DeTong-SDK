from enum import Enum, unique
import json
import sys
from urllib import request, parse

import numbers

# 相关请求大分组常量
CONTROL_LPAPI = "lpapi"
CONTROL_LOCAL = "local"

# 请求函数常量
ACTION_Version = "Version"
ACTION_SetSupportedPrinters = "SetSupportedPrinters"
ACTION_GetDefaultPrinter = "GetDefaultPrinter"
ACTION_SetDefaultPrinter = "SetDefaultPrinter"
ACTION_DiscoveryPrinters = "DiscoveryPrinters"
#
ACTION_GetPrinters = "GetPrinters"
ACTION_OpenPrinter = "OpenPrinter"
ACTION_ClosePrinter = "ClosePrinter"
ACTION_IsPrinterOpened = "IsPrinterOpened"
ACTION_IsPrinterOnline = "IsPrinterOnline"
ACTION_GetPrinterName = "GetPrinterName"
ACTION_GetPrinterDPI = "GetPrinterDPI"
ACTION_ShowProperty = "ShowProperty"
ACTION_PrintImageD = "PrintImageD"
ACTION_PrintRawData = "PrintRawData"
ACTION_PrintPackage = "PrintPackage"
ACTION_Print = "Print"
# //
ACTION_GetParam = "GetParam"
ACTION_SetParam = "SetParam"
ACTION_GetItemOrientation = "GetItemOrientation"
ACTION_SetItemOrientation = "SetItemOrientation"
ACTION_GetItemHorizontalAlignment = "GetItemHorizontalAlignment"
ACTION_SetItemHorizontalAlignment = "SetItemHorizontalAlignment"
ACTION_GetItemVerticalAlignment = "GetItemVerticalAlignment"
ACTION_SetItemVerticalAlignment = "SetItemVerticalAlignment"
ACTION_StartJob = "StartJob"
ACTION_AbortJob = "AbortJob"
ACTION_CommitJob = "CommitJob"
ACTION_GetJobID = "GetJobID"
ACTION_GetJobInfo = "GetJobInfo"
ACTION_GetPageInfo = "GetPageInfo"
ACTION_GetPageImage = "GetPageImage"
ACTION_StartPage = "StartPage"
ACTION_EndPage = "EndPage"
# //
ACTION_DrawText = "DrawText"
ACTION_Draw1DBarcode = "Draw1DBarcode"
ACTION_Draw2DQRCode = "Draw2DQRCode"
ACTION_Draw2DPdf417 = "Draw2DPdf417"
ACTION_Draw2DDataMatrix = "Draw2DDataMatrix"
ACTION_DrawRectangle = "DrawRectangle"
ACTION_FillRectangle = "FillRectangle"
ACTION_DrawRoundRectangle = "DrawRoundRectangle"
ACTION_FillRoundRectangle = "FillRoundRectangle"
ACTION_DrawEllipse = "DrawEllipse"
ACTION_FillEllipse = "FillEllipse"
ACTION_DrawLine = "DrawLine"
ACTION_DrawDashLine = "DrawDashLine"
ACTION_DrawImage = "DrawImage"
ACTION_DrawImageD = "DrawImageD"
ACTION_ReturnDrawResult = "ReturnDrawResult"
# local Action
ACTION_ServerInfo = "ServerInfo"

# 响应参数常量
RESP_STATUS_CODE = "statusCode"
""" 接口处理状态码 """
RESP_RESULT_INFO = "resultInfo"
""" 返回参数详细信息 """

LPA_RESULT_OK = 0
""" HTTP请求成功状态码 """

LPA_RESULT_PARAM_ERROR = 1
""" 函数参数错误 """
LPA_RESULT_SYSTEM_ERROR = 2
"""系统错误，如创建 Windows 对象失败、内存不足等"""
LPA_RESULT_NOSUPPORTED_PRINTER = 3
"""没有找到 LabelPrintAPI 支持的打印机"""
LPA_RESULT_UNSUPPORTED_PRINTER = 4
"""API 不支持指定名称的打印机"""
LPA_RESULT_NOPRINTDATA = 5
"""没有需要打印的数据"""
LPA_RESULT_NOPAGEDIMENSION = 6
"""没有打印页面尺寸信息"""
LPA_RESULT_INVALID_FILE = 7
"""无效的图片文件"""
LPA_RESULT_UNSUPPORTED_FUNCTION = 8
"""不支持的功能"""
LPA_RESULT_INVALID_FONTNAME = 9
"""字体名称错误"""

LPA_RESULT_NETWORK_FAILD = 90
"""网络请求失败"""
LPA_RESULT_NETWORK_TIMEOUT = 91
"""网络请求超时"""
LPA_RESULT_NETWORK_ERROR = 92
"""网络请求错误"""
LPA_RESULT_NETWORK_ABORT = 93
"""网络请求被取消"""
LPA_RESULT_NETWORK_UNSUPPORT = 94
"""不被支持的http请求环境"""
LPA_RESULT_NETWORK_EXCEPTION = 95
"""被捕获的未知网络异常"""

METHOD_GET = "GET"
METHOD_POST = "POST"

DEFAULT_IP = "127.0.0.1"
DEFAULT_PORT1 = 15216
DEFAULT_PORT2 = 35216
DEFAULT_TIMEOUT = 2000
DEFAULT_LINE_WIDTH = 0.4
DEFAULT_RECT_WIDTH = 20
DEFAULT_RADIUS = 10
DEFAULT_FONT_HEIGHT = 3.5
DEFAULT_FONT_NAME = "黑体"


class LPA_ParamID(Enum):
    """
    打印参数ID。可通过接口GetParam/SetParam来获取或者设置对应的参数。
    """
    GapType = 1
    """纸张类型。对应的value值可参考属性: LPA_GapType """
    PrintDarkness = 2
    """打印浓度。对应的value值参考: LPA_PrintDarkness """
    PrintSpeed = 3
    """ 打印速度。对应的value值可参考: LPA_PrintSpeed """
    PrinterDPI = 4
    """ 打印机分辨率，用于获取当前打印机的分辨率，或者设置预览时的默认分辨率。 """


class LPA_GapType(Enum):
    """ 
    纸张间隔类型
     """
    Unset = 255
    """ 随打印机设置 """
    POS = 0
    """ 连续纸（小票纸） """
    Hole = 1
    """ 定位孔 """
    Gap = 2
    """ 间隙纸 """
    Black = 3
    """ 黑标纸 """


class LPA_PrintSpeed(Enum):
    """
    打印速度常用值，实际有效值为1到5之间。
    """
    Unset = 255
    """ 随打印机设置 """
    Min = 0
    """ 最慢 """
    Low = 1
    """ 较慢 """
    Normal = 2,
    """ 正常速度 """
    High = 3
    """ 较块 """
    Max = 4
    """ 最快 """


class LPA_PrintDarkness(Enum):
    """
    打印浓度常用枚举值，打印浓度可以0到14之间的任意值。
    """
    Unset = 255
    """ 随打印机设置 """
    Min = 0
    """ 最淡 """
    Low = 3
    """ 较淡 """
    Normal = 5
    """ 正常 """
    High = 9
    """ 较浓 """
    Max = 14
    """ 最浓 """


class LPA_ItemAlignment(Enum):
    """
    绘制内容的对齐方式。
    """
    Start = 0
    """ 水平居左(垂直居上) 对齐 """
    Center = 1
    """ 水平（垂直）居中对齐 """
    End = 2
    """ 水平居右（垂直居下）对齐 """
    Stretch = 3
    """ 拉伸（多余空间使用空白填充） """
    Expand = 4
    """ 放大（多余空间通过放大填充） """


class LPA_FontStyle(Enum):
    """
    字体样式。
    """
    Regular = 0
    """ 一般字体样式 """
    Bold = 1
    """ 粗体 """
    Italic = 2
    """ 斜体 """
    BoldItalic = 3
    """ 粗斜体 """
    Underline = 4
    """ 下划线 """
    Strikeout = 8
    """ 删除线 """


class LPA_AutoReturnMode(Enum):
    """
    绘制字符串的时候的自动换行模式
    """
    No = 0
    """ 不进行自动换行 """
    Char = 1
    """ 按照字自动换行 """
    Word = 2
    """ 按照词自动换行 """


class LPA_BarcodeType(Enum):
    """
    一维条码编码类型。

    UPC-A, UPC-E, EAN13, EAN8, ISBN 统称为商品码，编码和显示方式类似；
    只能包含数字，对于支持两段的方式的编码，使用“+”来作为前后两段的分隔；
    都有校验字符，一般为0～9。对于 ISBN 编码，其校验字符可能为“X”。
    """
    LPA_1DBT_UPC_A = 20
    """
    支持长度为：12、12+2、12+5，显示为 1+5+5+1
    输入长度为 12：表示已经有校验码；
               11：没有校验码，程序会自动添加；
             < 11：加上前导零，然后自动添加校验码；
    """
    LPA_1DBT_UPC_E = 21
    """
     * 支持长度为：8、8+2、8+5，显示为1+6+1。其中第一位是编码数字类型，只
     * 能为0/1，表示采用的数字系统；第八位是校验位，采用 upc_check() 进行校验。
     * 输入长度为 8：表示已经有校验码，如果第一个字符不是0/1，则强制换成0来处理；
     *           7：没有校验码，程序会自动添加。如果第一个字符不是0/1，则强制换成0来处理；
     *           6：没有校验码，程序会自动添加。同时采用数字系统 0 来进行编码。
     *         < 6：加上前导 0 到长度为 6 之后，再进行编码。
    """
    LPA_1DBT_EAN13 = 22
    """
     * 支持长度为：13、13+2、13+5、8、8+2、8+5、5、2。
     * 输入长度为 13：表示已经有校验码；
     *           12：没有校验码，程序会自动添加；
     *         6~11：加上前导零之后，当成长度为 12 的处理；
     * 输入长度为 3/4/5：表示编码成长度为 5 的附加条码；
     *             1/2：表示编码成长度为 2 的附加条码。
    """
    LPA_1DBT_EAN8 = 23
    """
     * 在内部和 EAN13 编码统一处理
     *
     * 输入长度为 8：表示已经有校验码；
     * 输入长度大于 8 时，切换成 EAN13 码进行编码；
     * 输入长度 <= 5 时，切换成 EAN13 码进行编码；
     * 输入长度为 7：没有校验码，程序会自动添加；
     *           6：加上前导零，然后自动添加校验码；
     """
    LPA_1DBT_CODE39 = 24
    """
     * 1、"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%"
     * 2、以 * 为显示用引导和结束字符（编码中没有，仅仅显示用）
     * 3、每个字符用10个编码（显示长度为13）
     * 4、引导字符10个（显示长度为13），结束字符9个（显示长度12）
     * ==》字符数为 10+ 9+10×N
     *        显示长度 13+12+13×N
     *        10个字符 13+12+13×10 = 155像素
     * 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
    """
    LPA_1DBT_ITF25 = 25
    """
     * 1、0~9
     * 2、加校验码之后长度必须是偶数，否则在头部加上 0
     * 3、每个字符用5个编码（显示长度为 7）
     * 4、引导字符 4 个（显示长度为 4），结尾字符 3 个（显示长度是 4）
     * ==》字符数为 4 + 3 + 10*（N/2）
     *        显示长度 4 + 4 + 14*（N/2）
     *        10个字符 4+4+14×5 = 78像素
     * 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
    """
    LPA_1DBT_CODABAR = 26
    """
     * 1、"0123456789-$:/.+ABCD"，多应用于医疗领域
     * 2、引导/结束字符 A～D，都会被转化为大写
     * 3、加上引导字符/校验码之后，数据统一编码；
     * 4、每个字符用8个编码（显示长度为 10～11）
     * ==》字符数为 8×N，显示长度为 10×N～11×N
     *        10个字符10×10 + 11×2 = 122像素
     * 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
    """
    LPA_1DBT_CODE93 = 27
    """
     * 0x00～0x7F
     * 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
    """
    LPA_1DBT_CODE128 = 28
    """
     * 0x00～0xFF，CODE 128 A/B 支持全字符，对于 CODE 128 C 编码：
     *
     * 1、有固定方式的校验码，都是数字，必须是偶数长度
     * 2、引导字符 105，结束字符 106
     * 3、条码宽度范围为1～4，每个字符用7个编码（显示长度为11）
     * ==》字符数为 7+7+7+7×（N/2）
     *        显示长度 11+11+11+11×（N/2）
     *        10个字符 11+11+11+11×（10/2）= 88像素
    """
    LPA_1DBT_ISBN = 29
    """
     * 0~9，最后一位可能为 0~9, X（校验字符）
     * 13：必须是 978/979 前导，用 EAN13 编码，isbn13_check
     * 10：加上 978 前导之后，用 EAN13 编码，isbn_check
     * <=9：加上 0 前导之后，Check，然后再加上 978 前导，用 EAN 13 编码
     * 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
    """
    LPA_1DBT_ECODE39 = 30
    """
     * EXTENDED CODE 39，0x00～0x7F
     *
     * 对于 CODE 39 不支持的字符，采用转义之后，用两个字符来表示
     * 如果编码内容中包含不支持的字符，则会切换成 CODE 128 编码；
    """
    LPA_1DBT_AUTO = 60
    """
     * 根据编码内容，自动选择最适合的编码类型进行编码。
     *
     * 1、ITF25（内容长度为偶数，并且全部为数字时）
     * 2、CODABAR（如果内容以A/B/C/D开头，又以A/B/C/D结尾的话）
     * 3、CODE 39
     * 4、CODE 128
    """


class LPA_JobNames(Enum):
    """
    打印任务名称，在startJob接口中可以通过设置不同的 jobName 获取不同的base64图片。
    """
    Preview = '#!#Preview#!#'
    """ 用于生成白色底色预览图片 """
    Transparent = '#!#Transparent#!#'
    """ 用于生成透明底色的透明图片 """
    Print = "dtpweb-python"
    """ 默认打印任务名称 """


class LPA_BackgroundMode(Enum):
    """
    创建预览任务时生成图片的模式
    """
    Print = 0
    """ 直接打印 """
    White = 1
    """ 生成白色底色的图片 """
    Transparent = 2
    """ 生成透明底色的图片 """


@unique
class LPA_Result(Enum):
    """
    dtpweb接口处理结果状态码。
    """
    OK = 0
    """ http请求成功状态码 """
    PARAM_ERROR = 1
    """ 函数参数错误 """
    SYSTEM_ERROR = 2
    """ 系统错误，如创建 Windows 对象失败、内存不足等 """
    NOSUPPORTED_PRINTER = 3
    """ 没有找到 LabelPrintAPI 支持的打印机 """
    UNSUPPORTED_PRINTER = 4
    """ API 不支持指定名称的打印机 """
    NOPRINTDATA = 5
    """ 没有需要打印的数据 """
    NOPAGEDIMENSION = 6
    """ 没有打印页面尺寸信息 """
    INVALID_FILE = 7
    """ 无效的图片文件 """
    UNSUPPORTED_FUNCTION = 8
    """ 不支持的功能 """
    INVALID_FONTNAME = 9
    """ 字体名称错误 """
    NETWORK_FAILD = 90
    """ 网络请求失败 """
    NETWORK_TIMEOUT = 91
    """ 网络请求超时 """
    NETWORK_ERROR = 92
    """ 网络请求错误 """
    NETWORK_ABORT = 93
    """ 网络请求被取消 """
    NETWORK_UNSUPPORT = 94
    """ 不被支持的http请求环境 """
    NETWORK_EXCEPTION = 95
    """ 被捕获的未知网络异常 """


class LPA_BarcodeFlags(Enum):
    """
    一维条码编码类型。
    """
    ShowReadNone = 0x00
    """ 不显示供人识读字符。 """
    ShowReadDown = 0x01
    """ 是否在条码下方显示供人识读字符？"""
    ShowReadUp = 0x02
    """ 是否在条码上方显示供人识读字符？"""
    ShowStartStop = 0x04
    """ 是否显示 CODE 39 编码的起始终止符？"""
    EanCheckCode = 0x08
    """ 是否自动修正商品码的校验字符？"""


class LPA_QRTextEncoding(Enum):
    """
    QRCode 字符串编码方式。
    """
    Unicode = 0
    """ Unicode 编码 """
    Ansi = 1
    """ Ansi/DBCS 编码 """
    UTF8 = 2
    """ UTF-8 编码 """


class LPA_QREncodeMode(Enum):
    """
    QRCode 编码模式。
    """
    ModeNum = 0
    """ Numeric mode """
    ModeAn = 1
    """ Alphabet-numeric mode """
    Mode8Bit = 2
    """ 8-bit data mode """
    ModeKanji = 3
    """ Kanji (shift-jis) mode """
    ModeStructure = 4
    """ Internal use only """
    ModeEci = 5
    """ ECI mode """
    ModeFnc1First = 6
    """ FNC1, first position """
    ModeFnc1Second = 7
    """ FNC1, second position """


class LPA_QREccLevel(Enum):
    """
    二维码纠错级别枚举值
    """
    EccLevel_L = 0
    """ Low """
    EccLevel_M = 1
    """ Middle """
    EccLevel_Q = 2
    """ Quality """
    EccLevel_H = 3
    """ High """


class LPA_P417TextEncoding(Enum):
    """
    Pdf417 字符串编码方式。
    """
    Unicode = 0
    """ Unicode 编码 """
    Ansi = 1
    """ Ansi/DBCS 编码 """
    UTF8 = 2
    """ UTF-8 编码 """


class LPA_P417EncodeMode(Enum):
    """
    Pdf417 编码模式。
    """
    ModeAuto = 0
    """ Auto mode """
    ModeNumeric = 1
    """ Numeric mode """
    ModeText = 2
    """ Text mode """
    ModeBinary = 3
    """ Binary mode """


class LPA_P417EccLevel(Enum):
    """
    Pdf417 纠错模式。
    """
    EccLevel_Auto = 0
    EccLevel_1 = 1
    EccLevel_2 = 2
    EccLevel_3 = 3
    EccLevel_4 = 4
    EccLevel_5 = 5
    EccLevel_6 = 6
    EccLevel_7 = 7
    EccLevel_8 = 8


class LPA_DeviceType(Enum):
    """
    获取到的打印机设备的类型。
    """
    Local = 1
    """ 本地打印机机 """
    Net = 2
    """ 局域网内其他电脑上的打印机 """
    Wifi = 3
    """ 局域网内自带网络功能的打印机 """


class LPA_SourceImageFormat(Enum):
    """
    打印或者生成图片的相关格式。
    """
    LPASIF_RAWDATA = 0
    """ 直接传递给打印机的原始打印数据 """
    LPASIF_BPP_1 = 1
    """
    每个点用一个比特位表示的黑白点阵数据，1 表示黑点（需要打印），0 表示白点
     
     数据从上至下按照行来存放，每行需要的字节数为 (width + 7) / 8。
     每个字节表示 8 个点，高位表示左边的点，低位表示右边的点。
    """
    LPASIF_BPP_1N = 2
    """同 LPASIF_BPP_1，只是 0 表示黑点（需要打印），1 表示白点"""
    LPASIF_32_RGBA = 32
    """ 每个点用四个字节表示的点阵数据，四个字节依次表示 RGBA """
    LPASIF_32_BGRA = 33
    """ 每个点用四个字节表示的点阵数据，四个字节依次表示 BGRA """
    LPASIF_32_RGB = 34
    """ 每个点用四个字节表示的点阵数据，四个字节依次表示 RGB，最高字节未使用 """
    LPASIF_32_BGR = 35
    """ 每个点用四个字节表示的点阵数据，四个字节依次表示 BGR，最高字节未使用 """
    LPASIF_PACKAGE = 90
    """
    简易报文格式的点阵数据，1 表示黑点（需要打印），0 表示白点，对于标签打印而言，压缩效率还是不错的。
      
      打印行：Ax 前导零字节数 打印字节数 xxxxxx
             首字节的4个比特，给前导零用2位，给打印字节用2位，也就是说打印数据最多为1K字节，8K个点。
      打印行：B0 xxxxxx
             打印字节数等于点阵数据的行字节数，(width + 7) / 8。
      重复行：Bx
             首字节的4个比特，给行数使用，也就是说行数最大值为 15。
      空白行：110xxxxx（也即 Cx/Dx）
             首字节的5个比特，给行数使用，也就是说行数最大值为 31。
     """
    LPASIF_IMAGEDATA = 93
    """
    图片文件数据，支持 PNG/JPG/BMP 等几乎所有常见图片文件格式。
      
      如果图片文件数据采用 Base64 编码（通过设置 dLen = 0 实现），则会自动过滤字符串开始的诸如
      “data:image/png;base64,”的头部字符串，这种头部字符串一般在 JS 中被广泛使用，用于指示图片
      数据格式。接口会自动查找头部的部分字符，一直找到“,”为止。如果没有找到“,”，则数据从头开始。
    """


def url_encode(query):
    """
    先去掉值为None的属性，然后再进行url编码处理
    """
    if not isinstance(query, dict):
        return query
    #
    for key in list(query.keys()):
        if query.get(key) is None:
            query.pop(key)
    return parse.urlencode(query, quote_via=parse.quote)


def http_request(url, host=None, port=None, method=None, param=None, headers=None, data=None, timeout=None):
    # 参数检查
    if not url:
        return {
            RESP_STATUS_CODE: LPA_RESULT_PARAM_ERROR,
            RESP_RESULT_INFO: "LPA_RESULT_PARAM_ERROR"
        }
    #
    config = get_request_data(locals())
    if not config.get("host"):
        config["host"] = host = DEFAULT_IP
    if not config.get("port"):
        config["port"] = port = DEFAULT_PORT1
    if not config.get("method"):
        config["method"] = method = METHOD_GET
    if not config.get("timeout"):
        config["timeout"] = timeout = DEFAULT_TIMEOUT
    if not config.get("headers"):
        config["headers"] = headers = {}
    # dict的数据需要先转换成字符串
    if isinstance(data, dict):
        data = url_encode(data)
    # 非字符串数据不做处理
    if not isinstance(data, str):
        data = None
    # url参数处理
    if isinstance(param, dict):
        param = url_encode(param)
    if isinstance(param, str) and param and '?' not in url:
        url = "{}?{}".format(url, param)
    #
    if not url.startswith("/"):
        url = "/" + url
    request_url = "http://{0}:{1}{2}".format(host, port, url)
    # 配置请求参数
    # print("----------")
    # print(config)
    # print("requestUrl = {0}".format(request_url))
    # print("-----------")
    #
    if isinstance(data, str):
        data = bytes(data, encoding='utf-8')
    try:
        req = request.Request(request_url, method=method,
                              headers=headers, data=data)
        # 发送请求
        resp = request.urlopen(req, timeout=timeout)
        result = resp.read().decode()
        return json.loads(result)
    except TimeoutError:
        return {
            RESP_STATUS_CODE: LPA_RESULT_NETWORK_TIMEOUT,
            RESP_RESULT_INFO: "request timeout of {} ms".format(timeout)
        }
    except:
        return {
            RESP_STATUS_CODE: LPA_Result.NETWORK_FAILD.value,
            RESP_RESULT_INFO: sys.exc_info()
        }


def get_request_data(allArgs):
    """
    修正给定的字典参数
    :param allArgs:
    :return:
    """
    if not isinstance(allArgs, dict):
        return allArgs
    #
    values = {}
    if "self" in allArgs:
        del allArgs["self"]
    if "kwargs" in allArgs and isinstance(allArgs["kwargs"], dict):
        values.update(allArgs["kwargs"])
        del allArgs["kwargs"]
    #
    if "kargs" in allArgs and isinstance(allArgs["kargs"], dict):
        values.update(allArgs["kargs"])
        del allArgs["kargs"]
    #
    values.update(allArgs)
    #
    return values


def unit_convert(v):
    """
    单位转换，将毫米单位转换为0.01毫米
    :param int v:
    :return: int
    """
    return float(v if v else 0) * 100


def convert_line_width(options):
    """
    直线宽度单位转换
    :param dict options:
    :return:
    """
    options["lineWidth"] = unit_convert(
        options["lineWidth"] if "lineWidth" in options and options["lineWidth"] else DEFAULT_LINE_WIDTH)
    #
    return options


def convert_of_job(options):
    """
    打印任务相关单位转换
    :param dict options:
    :return:
    """
    # 将绘制相关单位转换为0.01毫米
    options["scaleUnit"] = 1
    options["width"] *= 100
    options["height"] *= 100
    #
    return options


def convert_of_base(options):
    """
    将字典对象中的基本属性进行单位转换
    :param dict options:
    :return:
    """
    if options is None:
        return options
    #
    if "x" in options and options["x"]:
        options["x"] = unit_convert(options["x"])
    if "y" in options and options["y"]:
        options["y"] = unit_convert(options["y"])
    if "width" in options and options["width"]:
        options["width"] = unit_convert(options["width"])
    if "height" in options and options["height"]:
        options["height"] = unit_convert(options["height"])
    #
    return options


def convert_of_rect(options):
    """
    将字典对象中的基本属性进行单位转换
    :param dict options:
    :return:
    """
    if options is None:
        return options
    #
    if "width" not in options or options["width"] is None:
        options["width"] = DEFAULT_RECT_WIDTH
    if "height" not in options or options["height"] is None:
        options["height"] = options["width"]
    #
    convert_of_base(options)
    convert_line_width(options)
    #
    return options


def convert_of_round_rect(options):
    """
    将字典对象中的基本属性进行单位转换
    :param dict options:
    :return:
    """
    if options is None:
        return options
    #
    convert_of_rect(options)
    key = "cornerWidth"
    corner = options[key] if key in options else None
    key = "cornerHeight"
    corner = options[key] if not corner and key in options else corner
    #
    if corner:
        #
        key = "cornerWidth"
        if key not in options or not options[key]:
            options[key] = corner
        options[key] = unit_convert(options[key])
        #
        key = "cornerHeight"
        if key not in options or not options[key]:
            options[key] = corner
        options[key] = unit_convert(options[key])
    #
    return options


def convert_of_line(options):
    """
    将字典对象中的基本属性进行单位转换
    :param dict options:
    :return:
    """
    if options is None:
        return options
    #
    if "x1" not in options or options["x1"] is None:
        options["x1"] = 0
    if "x2" not in options or options["x2"] is None:
        options["x2"] = options["x1"]
    if "y1" not in options or options["y1"] is None:
        options["y1"] = 0
    if "y2" not in options or options["y2"] is None:
        options["y2"] = options["y1"]
    #
    options["x1"] = unit_convert(options["x1"])
    options["x2"] = unit_convert(options["x2"])
    options["y1"] = unit_convert(options["y1"])
    options["y2"] = unit_convert(options["y2"])
    #
    convert_line_width(options)
    #
    if "dashLens" in options:
        dash_lens = options["dashLens"]
        # 如果制定了单个数字，则可以拼接成虚实相等的数组
        if isinstance(dash_lens, numbers.Number):
            dash_lens = [dash_lens]
        if isinstance(dash_lens, list):
            # 虚实线最少要包含两个元素
            if len(dash_lens) == 1:
                dash_lens.append(dash_lens[0])
            #
            for i in range(len(dash_lens)):
                dash_lens[i] = unit_convert(dash_lens[i])
            #
            options["dashLen"] = ",".join(str(item) for item in dash_lens)
            options["dashCount"] = len(dash_lens)
        del options["dashLens"]
    #
    return options


def convert_of_circle(options):
    """
    圆形相关参数的矫正处理
    :param dict options:
    :return:
    """
    if not isinstance(options, dict):
        return options
    #
    radius = DEFAULT_RADIUS
    if "radius" in options:
        radius = options["radius"]
        del options["radius"]
    if not isinstance(radius, int) and not isinstance(radius, float):
        radius = DEFAULT_RADIUS
    if radius <= 0:
        radius = DEFAULT_RADIUS
    #
    if "x" not in options or not isinstance(options["x"], numbers.Number):
        options["x"] = 0
    if "y" not in options or not isinstance(options["y"], numbers.Number):
        options["y"] = 0
    options["x"] -= radius
    options["y"] -= radius
    options["width"] = options["height"] = radius * 2
    # 已经变成了普通的椭圆绘制参数选项了
    convert_of_rect(options)
    #
    return options


def check_and_set(options, key, value):
    """
    检查指定的option字典中有没有给定的key值，如果没有则设置对应的值
    """
    if key not in options or not options[key]:
        options[key] = value


def convert_of_text(options):
    """
    文本绘制相关参数的转换
    :param dict options:
    :return:
    """
    if options is None:
        return options
    #
    convert_of_base(options)
    # 设置默认字体高度
    key = "fontHeight"
    check_and_set(options, key, DEFAULT_FONT_HEIGHT)
    options[key] = unit_convert(options[key])
    # 设置默认字体名称
    check_and_set(options, "fontName", DEFAULT_FONT_NAME)
    # 缩进处理
    key = "leadingIndent"
    keyChar = "leadingIndentChars"
    keyMM = "leadingIndentMM"
    keyColon = "leadingIndentColon"
    if key in options and options[key]:
        if keyChar in options and options[keyChar]:
            # leadingIndent = 10表示向左缩进1个字符的高度。
            options[key] = options[keyChar] * 10
            del options[keyChar]
        elif keyMM in options and options[keyMM]:
            # leadingIndent = 1100,表示向左缩进1mm的宽度。
            if options[keyMM] >= 0.01:
                options[key] = options[keyMM] * 100 + 1000
            elif options[keyMM] <= -0.01:
                options[key] = options[keyMM] * 100 - 1000
            #
            del options[keyMM]
        elif keyColon in options and options[keyColon]:
            #
            options[key] = 1000
            del options[keyColon]
    if key in options and not options[key]:
        del options[key]
    # 区域绘制
    key = "regionCorners"
    if key in options and options[key]:
        value = options[key]
        if isinstance(value, str):
            value = value.split(",")
        if isinstance(value, list) and len(value) >= 2:
            for i in range(len(value)):
                value[i] = str(unit_convert(value[i]))
            options[key] = ",".join(value)
    else:
        keys = [
            "regionLeftUpCorner",
            "regionRightUpCorner",
            "regionRightBottomCorner",
            "regionLeftBottomCorner"
        ]
        corner_list = []
        for i in range(len(keys)):
            # 取值
            key = keys[i]
            corner_list.append(options[key] if key in options else None)
        if corner_list[0] or corner_list[1] or corner_list[2] or corner_list[3]:
            for i in range(len(corner_list)):
                corner_values = corner_list[i]
                # 如果值为字符串，则分割成数组
                if isinstance(corner_values, str):
                    corner_values = corner_values.split(",")
                if isinstance(corner_values, list):
                    if len(corner_values) > 2:
                        corner_values = corner_values[0:2]
                    for j in range(2):
                        if j < len(corner_values):
                            corner_values[j] = str(
                                unit_convert(corner_values[j]))
                        else:
                            corner_values.append("0")
                    corner_values = ",".join(corner_values)
                else:
                    corner_values = "0,0"
                corner_list[i] = corner_values
            #
            options["regionCorners"] = ",".join(corner_list)
    #
    keys = ["regionLeftBorders", "regionRightBorders"]
    for i in range(len(keys)):
        key = keys[i]
        if key in options and options[key]:
            borders = options[key]
            if isinstance(borders, str):
                borders = borders.split(",")
            # 每个空白区域必须包含三个属性，width, Y, height,所以数组长度不能小于3
            if isinstance(borders, list) and len(borders) > 2:
                for index in range(len(borders)):
                    borders[index] = str(unit_convert(borders[index]))
                options[key] = ",".join(borders)
            else:
                del options[key]

    return options
