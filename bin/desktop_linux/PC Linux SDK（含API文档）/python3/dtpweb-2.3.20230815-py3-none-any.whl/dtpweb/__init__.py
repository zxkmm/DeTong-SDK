"""
DothanTech dtpweb interface for python
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

dtpweb 是一个基于底层打印助手进行二次封装的 python 接口

用法：
    >>> from dtpweb import DTPWeb
    >>> api = DTPWeb()
"""

from .__version__ import __title__, __version__

from .api import DTPWeb
from .utils import LPA_QREccLevel, LPA_FontStyle, LPA_ItemAlignment, LPA_BarcodeType, LPA_AutoReturnMode
