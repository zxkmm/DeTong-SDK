"""
通过Python代码对底层接口进行二次封装，方便用户使用。
"""

from . import utils
from .utils import CONTROL_LOCAL, LPA_RESULT_OK, RESP_RESULT_INFO, RESP_STATUS_CODE, LPA_Result

LPA_PID_GAP_TYPE = 1
LPA_PID_PRINT_DARKNESS = 2
LPA_PID_PRINT_SPEED = 3
LPA_PID_PRINTER_DPI = 4

LPA_PARAM_VALUE_UNSET = 255
LPA_GAP_TYPE_NONE = 0
LPA_GAP_TYPE_HOLE = 1
LPA_GAP_TYPE_GAP = 2
LPA_GAP_TYPE_BLACK = 3

TIMEOUT_LONG = 5000
TIMEOUT_SHORT = 2000


def mm_to_pound(value):
    """
    将给定的毫米值转换为磅值。
    该函数常用于绘制字符串的时候字体大小的单位换算。
    :param value: 待转换的值，单位毫米。
    :return: 转换后的值，单位磅。
    """
    return value * 25.4 / 72


def pound_to_mm(value):
    """
    将给定的磅值转换为毫米值。

    该函数常用于绘制字符串的时候字体大小的单位换算。
    :param value: 待转换的值，单位磅。
    :return: 转换后的值，单位毫米。
    """
    return value * 72 / 25.4


class DTPWeb:
    """
    基于底层dtpweb打印助手封装的python打印接口。
    """

    def __init__(self, **kwargs):
        self.__version = None
        # self.__serviceName = None
        self.__ipAddress = None
        self.__init_ip = None
        self.__init_port = None
        self.__ip = None
        self.__port = None
        self.__deviceType = None
        #
        self.__fontName = None
        self.__fontHeight = None
        self.__lineWidth = None
        self.__radius = None
        #
        self.init(**kwargs)

    def init(self, **kwargs):
        #
        for k, v in kwargs:
            if k == "ip" and v:
                self.__init_ip = v
            #
            if k == "fontName" and v:
                self.__fontName = v
            elif k == "fontHeight" and v:
                self.__fontHeight = v
            elif k == "lineWidth" and v:
                self.__lineWidth = v
            elif k == "radius" and v:
                self.__radius = v

    def set_server_info(self, info):
        if isinstance(info, dict) and "version" in info:
            ver = info["version"].split("/")
            if len(ver) > 1:
                self.__version = ver[1]

    def get_host(self, ip):
        return ip if ip else (self.__ip if self.__ip else self.__init_ip)

    def get_port(self, port):
        return port if port else (self.__port if self.__port else self.__init_port)

    def get_font_name(self, fontName):
        return fontName if fontName else (self.__fontName if self.__fontName else "黑体")

    def get_font_height(self, fontHeight):
        return fontHeight if fontHeight else (self.__fontHeight if self.__fontHeight else 3.5)

    def get_line_width(self, lineWidth):
        return lineWidth if lineWidth else (self.__lineWidth if self.__lineWidth else 0.4)

    def get_radius(self, radius):
        return radius if radius else (self.__radius if self.__radius else 10)

    def check_plugin(self, ip=None):
        """
        检查插件是否可用
        :param ip: 待检测目标ip
        :return:
        """
        # 检测端口1是否可用
        result = self.check_port(utils.DEFAULT_PORT1, ip)
        if not result:
            result = self.check_port(utils.DEFAULT_PORT2, ip)
        #
        print("★★★ 打印助手运行正常 ★★★" if result else "★★★ 未检测到打印助手 ★★★")
        print()
        return result

    def check_port(self, port=None, ip=None):
        """
        检测指定的端口号是否可用
        :param port:
        :param ip:
        :return:
        """
        print("<<< ----- DTPWeb request: checkPort({}) ----- >>>".format(port))
        ip = self.get_host(ip)
        url = "{0}/{1}".format(utils.CONTROL_LOCAL, utils.ACTION_ServerInfo)
        #
        resp = utils.http_request(url=url, host=ip, port=port)
        print("----- onResponse of check_port -----")
        print(resp)
        print("[[[[[ --------------------------------------- ]]]]]\n")
        if isinstance(resp, dict) and resp[utils.RESP_STATUS_CODE] < utils.LPA_RESULT_NETWORK_FAILD:
            # 检测成功
            result_info = resp[utils.RESP_RESULT_INFO]
            self.set_server_info(result_info)
            # 保存目标IP与端口号
            if ip:
                self.__init_ip = ip
            if port:
                self.__init_port = port
            return True
        #
        return False

    def request_api(self, action, ip=None, port=None, method=None, deviceType=None, control=None, data=None,
                    timeout=None):
        """
        发送指定的HTTP请求
        :param action: 请求方法。
        :param ip: 请求目标IP地址。
        :param port: 请求目标端口号。
        :param deviceType: 目标打印机类型。
        :param control: 请求控制器。
        :param data: 请求数据。
        :param timeout: 请求超时时间。

        :return dict: http请求结果
        """
        print("<<< ----- DTPWeb request: {0} ----- >>>".format(action))
        print(data)
        #
        ip = self.get_host(ip)
        port = self.get_port(port)
        control = control if control else utils.CONTROL_LPAPI
        method = method if method else utils.METHOD_POST
        data = data if isinstance(data, dict) else None
        # deviceType = deviceType if isinstance(deviceType, int) and deviceType > 0 else 1
        #
        blob = None
        if isinstance(data, dict) and "data" in data:
            blob = data["data"]
            del data["data"]
        # 获取get请求参数
        get_param = utils.url_encode(data) if isinstance(data, dict) else None
        # 获取post请求参数
        post_data = blob if blob else get_param
        url = "{}/{}".format(control, action)
        #
        content_type = "application/x-www-form-urlencoded;charset=UTF-8"
        # window环境下需要配置base64请求头
        if not self.__version:
            if isinstance(blob, str):
                content_type = 'application/octet-stream;encoding=base64'
        #
        result = utils.http_request(url=url, host=ip, port=port, method=method, headers={
            "Content-type": content_type
        }, param=data, data=post_data)

        # 打印响应信息
        print("----- onResponse: {} -----".format(action))
        print(result)
        print("[[[[[ --------------------------------------- ]]]]]\n")
        #
        return result

    def is_local_printer(self, type):
        if not self.__version and self.__version >= "2.3.2023.621":
            # 2.3.20230621及以后的版本中:
            #      1 - 9  : 表示本地打印机，一般为9，表示我们德佟系列的打印机，1表示除此之外的其他打印机。
            #      11 - 19: 表示网络打印机；
            #      29     ：表示WiFi打印机；
            return type < 10
        else:
            # 旧版本中 1：表示本地打印机，2：表示局域网打印机，3：表示WIFI打印机。
            return type <= 1

    def get_version(self):
        # 获取打印助手版本信息
        resp = self.request_api(utils.ACTION_Version)
        if isinstance(resp, dict) and resp[utils.RESP_STATUS_CODE] == LPA_RESULT_OK:
            return resp[utils.RESP_RESULT_INFO]
        else:
            return None

    def get_server_info(self):
        # 获取打印助手相关信息
        resp = self.request_api(utils.ACTION_ServerInfo, control=CONTROL_LOCAL)
        #
        if isinstance(resp, dict) and resp[utils.RESP_STATUS_CODE] == LPA_RESULT_OK:
            return resp[utils.RESP_RESULT_INFO]
        else:
            return None

    def setSupportedPrinters(self, supportedPrinters):
        # 打印机兼容性设置
        options = utils.get_request_data(locals())
        resp = self.request_api(
            utils.ACTION_SetSupportedPrinters, data=options)
        return isinstance(resp, dict) and resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def get_default_printer(self):
        #
        resp = self.request_api(utils.ACTION_GetDefaultPrinter)
        #
        if isinstance(resp, dict) and resp[RESP_STATUS_CODE] == LPA_RESULT_OK:
            return resp[RESP_RESULT_INFO]
        else:
            return None

    def set_default_printer(self, printerName):
        #
        options = utils.get_request_data(locals())
        resp = self.request_api(utils.ACTION_SetDefaultPrinter, data=options)
        return isinstance(resp, dict) and resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def get_printers(self, name=None, onlyLocal=None, onlyOnline=None, onlySupported=None):
        """
        获取打印机列表
        :param name: 只获取指定型号/名称的所有打印机（Windows系统不支持）。
        :param onlyLocal: 是否只获取本地打印机，默认为False（Linux系统不支持）。
        :param onlyOnline: 是否只获取在线打印机？默认为True（Linux系统不支持）。
        :param onlySupported: 是否只获取支持的打印机？默认为True（Linux系统不支持）。
        :return:
        """
        options = utils.get_request_data(locals())
        # 默认只获取在线打印机
        if options["onlyOnline"] is None:
            options["onlyOnline"] = True
        # 默认只获取支持的打印机
        if options["onlySupported"] is None:
            options["onlySupported"] = True
        result = self.request_api(
            utils.ACTION_GetPrinters, data=options, timeout=TIMEOUT_LONG)
        return result["resultInfo"]["printers"] if result["statusCode"] == 0 else []

    def open_printer(self, name=None, ip=None, type=None, **kwargs):
        """
        打开指定的打印机;

        :param name: 目标打印机名称，如果未指定，则自动链接检测到的打印机。
            如果有多台打印机，随机链接任何一台打印机，优先选择USB打印机。
        :param ip: 打开局域网内指定IP地址上支持的打印机。
        :param type: 打开指定类型的打印机，1表示本地打印机，2表示局域网内其他电脑上的打印机，3表示自带网络功能的打印机。
        :param kwargs: 其他字段属性。
        """
        options = name if isinstance(
            name, dict) else utils.get_request_data(locals())
        return self.request_api(utils.ACTION_OpenPrinter, data=options, timeout=TIMEOUT_LONG)

    def is_printer_opened(self):
        """如果打印机是否已经链接"""
        resp = self.request_api(utils.ACTION_IsPrinterOpened)
        return isinstance(resp, dict) and resp[utils.RESP_STATUS_CODE] == LPA_RESULT_OK

    def get_printer_name(self):
        """ 获取已连接的打印机名称 """
        resp = self.request_api(utils.ACTION_GetPrinterName)
        #
        if isinstance(resp, dict) and resp[utils.RESP_STATUS_CODE] == LPA_RESULT_OK:
            return resp[utils.RESP_RESULT_INFO]
        else:
            return None

    # def get_printer_info(self):
    #     """如果打印机已经链接，则获取已链接打印机相关信息"""
    #     return self.request_api(get_printer_info()

    def get_printer_dpi(self):
        """ 获取已连接打印机的打印分辨率 """
        return self.request_api(utils.ACTION_GetPrinterDPI)

    def close_printer(self):
        """关闭已链接的打印机"""
        self.request_api(utils.ACTION_ClosePrinter)

    def print_image(self, data, printerName=None, printWidth=None, printHeight=None,
                    threshold=None, orientation=None, copies=None, jobName=None, **kwargs):
        """
        打印给定的图片

        :param data: 打印的图片数据，正常情况下应该是图片URL或者BASE64图片。
        :param printerName: 打印机名称，不指定表示上次连接过的打印机。
        :param printWidth: 图片打印宽度，单位毫米，默认为0，表示按照图片的实际大小进行打印。
        :param printHeight: 图片打印高度，单位毫米，默认为0，表示按照图片的实际大小进行打印。
        :param threshold: 图片进行黑白转换时的阈值，默认为{@link CONSTANTS.THRESHOLD}。
        :param orientation: 图片打印方向，默认为0，表示打印前不进行图片的旋转操作。
        :param copies: 打印份数，默认只打印1份。
        :param jobName: 打印任务名称。
        :param kwargs: 其他相关打印参数。
        """
        options = utils.get_request_data(locals())
        options["scaleUnit"] = 1
        options["printWidth"] = utils.unit_convert(options["printWidth"])
        options["printHeight"] = utils.unit_convert(options["printHeight"])
        #
        resp = self.request_api(utils.ACTION_PrintImageD, data=options)
        return isinstance(resp, dict) and resp[utils.RESP_STATUS_CODE] == LPA_RESULT_OK

    def print(self, action, printerInfo, jobInfo, jobPages, jobArguments=None):
        return False

    def set_param(self, id, value):
        """
        设置打印参数
        :param id:
        :param value:
        :return:
        """
        options = utils.get_request_data(locals())
        resp = self.request_api(utils.ACTION_SetParam, data=options)
        return resp[utils.RESP_STATUS_CODE] == LPA_RESULT_OK

    def get_param(self, id):
        """获取指定的打印参数"""
        options = utils.get_request_data(locals())
        resp = self.request_api(utils.ACTION_GetParam, data=options)
        return resp.get(utils.RESP_RESULT_INFO) if resp[utils.RESP_STATUS_CODE] == utils.LPA_RESULT_OK else -1

    def set_gap_type(self, value):
        """ 设置已连接打印机的纸张类型 """
        return self.set_param(LPA_PID_GAP_TYPE, value)

    def get_gap_type(self):
        """ 获取已连接打印机的纸张类型 """
        return self.get_param(LPA_PID_GAP_TYPE)

    def set_print_darkness(self, value):
        """ 设置已连接打印机的打印浓度 """
        return self.set_param(LPA_PID_PRINT_DARKNESS, value)

    def get_print_darkness(self):
        """ 获取已连接打印机的打印浓度 """
        return self.get_param(LPA_PID_PRINT_DARKNESS)

    def set_print_speed(self, value):
        """ 设置已连接打印机的打印速度 """
        return self.set_param(LPA_PID_PRINT_SPEED, value)

    def get_print_speed(self):
        """ 获取已连接打印机的打印速度 """
        return self.get_param(LPA_PID_PRINT_SPEED)

    def set_printer_dpi(self, value):
        """ 设置预览模式下的默认图片分辨率 """
        return self.set_param(LPA_PID_PRINTER_DPI, value)

    def get_printer_dpi(self):
        """ 获取已连接打印机的打印机分辨率 """
        return self.get_param(LPA_PID_PRINTER_DPI)

    ##############################################
    # 绘制相关接口；
    ##############################################

    def start_job(self, width, height, orientation=None, jobName=None, **kwargs):
        """
        创建打印任务。

        创建打印任务时，如果没有链接打印机，则本函数会自动打开当前系统安装的第一个 LPAPI 支持的打印机，用于打印。
        当前还有未打印的任务，已有打印数据将会被全部丢弃。

        :param width: 标签宽度，单位毫米。
        :param height: 标签高度，单位毫米。
        :param orientation: 标签旋转方向，默认为0，表示不旋转。
        :param jobName: 打印任务名称。
        :param kwargs:
        :return:
        """
        options = utils.get_request_data(locals())
        if not options["height"]:
            options["height"] = options["width"]
        if not options["jobName"]:
            options["jobName"] = utils.LPA_JobNames.Print.value
        options = utils.convert_of_job(options)

        return self.request_api(utils.ACTION_StartJob, data=options)

    def start_page(self):
        """开始新的一页"""
        return self.request_api(utils.ACTION_StartPage)

    def end_page(self):
        """结束页面信息，用于多页打印"""
        return self.request_api(utils.ACTION_EndPage)

    def commit_job(self, gapType=None, darkness=None, speed=None, orientation=None, threshold=None, **kwargs):
        """
        提交打印任务，进行真正的打印。

        :param gapType: 纸张类型，默认随打印机设置。
        :param darkness: 打印浓度，默认随打印机设置。
        :param speed: 打印速度，默认随打印机设置。
        :param orientation: 打印方向，默认为`0`。`0`表示不旋转，`90`表示右转90度，`180`表示进行180度旋转，`270`表示左转90度。
        :param threshold: 图片进行黑白转换时的阈值。
        :param kargs: 其他关键字参数
        """
        options = utils.get_request_data(locals())
        return self.request_api(utils.ACTION_CommitJob, data=options)

    def get_page_info(self):
        """
        得到刚完成的打印任务的打印任务信息。
        """
        resp = self.request_api(utils.ACTION_GetPageInfo)
        return resp[RESP_RESULT_INFO] if resp[RESP_STATUS_CODE] == LPA_Result.OK else None

    def get_page_image(self, page=None):
        """获取当前打印任务中指定页的图片"""
        options = locals()
        if isinstance(options["page"], int):
            options["page"] = 0
        resp = self.request_api(utils.ACTION_GetPageImage, data=options)
        return resp[RESP_RESULT_INFO] if resp[RESP_STATUS_CODE] == LPA_Result.OK else None

    ##########################
    # 在画板上绘制相关对象
    ##########################

    def draw_text(self, text, x=None, y=None, width=None, height=None, fontHeight=None, fontStyle=None, fontName=None,
                  autoReturn=None, charSpace=None, lineSpace=None, leadingIndent=None, leadingIndentChars=None,
                  leadingIndentMM=None, leadingIndentColon=None, regionCorners=None, regionLeftUpCorner=None,
                  regionRightUpCorner=None, regionRightBottomCorner=None, regionLeftBottomCorner=None,
                  regionLeftBorders=None, regionRightBorders=None, onlyMeasureText=None,
                  horizontalAlignment=None, verticalAlignment=None, orientation=None, **kwargs):
        """
        绘制文本字符串

        regionCorners regionLeftUpCorner regionRightUpCorner regionRightBottomCorner
         regionLeftBottomCorner regionLeftBorders regionRightBorders，这些参数都是长度
         数组，建议都是通过数组来传递参数，这样接口会对长度都自动转发为接口使用的 0.01mm 的
         单位。为了调试方便，这些参数也支持逗号分隔的字符串方式来参数。但是此时参数必须调用者
         自己转发为 0.01mm 为单位的长度数据。

        :param text: 待绘制的文本数据。
        :param x: 水平方向上的坐标位置，单位毫米，值默认为0。
        :param y: 垂直方向上的坐标位置，单位毫米，值默认为0。
        :param width: 字符串显示区域宽度，单位毫米，值默认为0，表示不限制宽度。
        :param height: 字符串显示区域高度，单位毫米，值默认为0，表示不限制高度。
        :param fontHeight: 字符串字体高度，单位毫米，值必须大于0。
        :param fontName: 字体名称，默认为黑体。
        :param fontStyle: 字体样式，默认为常规字体。
        :param autoReturn: 自动换行模式，默认为 LPA_AutoReturnMode.Char，表示按字符换行。
        :param charSpace: 字符间距，默认为0，单位毫米。
        :param lineSpace: 行间距，单位毫米，或者字符串（1_0，1_2，1_5，2_0）。默认为 1_0，也即单倍行距。
        :param leadingIndent: 首行缩进的四个参数，默认为0。四选一，leadingIndent 具有最高优先级。
                                0         : 表示没有首行缩进；
                                1 ~ 999   : 表示首行向左缩进 N/10 个中文字符个数（字符高度）
                                1000      ：表示首行向左缩进到中文冒号、英文冒号、英文冒号+英文空格
                                > 1000    ：表示首行向左缩进 (N - 1000) 的 ScaleUnit
                                -999 ~ -1 : 表示首行向右缩进 -N/10 个中文字符个数（字符高度）
                                < -1000   ：表示首行向右缩进 (-N - 1000) 的 ScaleUnit
        :param leadingIndentChars: 根据指定的中文字符个数进行首行缩进。
                                    其值可以为小数，比方说 1.5表示 1.5 个中文字符 / 3 个英文字符。> 0 表示首行向左缩进，< 0表示首行向右缩进。
        :param leadingIndentMM: 根据指定的毫米数进行首行缩进。> 0 表示首行向左缩进，< 0 表示首行向右缩进。
        :param leadingIndentColon: 表示首行向左缩进到中文冒号、英文冒号、英文冒号+英文空格。
        :param regionCorners: 显示区域四个角的删除矩形，分别为左上、右上、右下、左下，格式为:
                                `[Width, Height, Width, Height, Width, Height, Width, Height]`，单位毫米。
        :param regionLeftUpCorner: 显示区域左上角的删除矩形，格式为：`[Width, Height]`，单位毫米。
        :param regionRightUpCorner: 显示区域右上角的删除矩形，格式为：`[Width, Height]`，单位毫米。
        :param regionRightBottomCorner: 显示区域右下角的删除矩形，格式为：`[Width, Height]`，单位毫米。
        :param regionLeftBottomCorner: 显示区域左下角的删除矩形，格式为：`[Width, Height]`，单位毫米。
        :param regionLeftBorders: 显示区域左边的删除矩形，最多支持删除两个矩形，
                                    格式为：`[Width, Y, Height, Width, Y, Height]`，单位毫米。
        :param regionRightBorders: 显示区域右边的删除矩形，最多支持删除两个矩形，
                                    格式为：`[Width, Y, Height, Width, Y, Height]`，单位毫米。
        :param onlyMeasureText: 表示仅仅度量、而不真正的绘制文本。
        :param horizontalAlignment: 对象显示水平对齐方式，在指定了宽度的情况下有效。
        :param verticalAlignment: 对象显示垂直对齐方式，在指定了高度的情况下生效。
        :param orientation: 设置绘制对象的旋转角度，值为0、90、180、270。默认为0，表示不做任何旋转处理。
        :param kwargs: 关键字参数
        {
        }
        """
        options = utils.get_request_data(locals())
        options["fontName"] = self.get_font_name(fontName)
        options = utils.convert_of_text(options)
        #
        resp = self.request_api(utils.ACTION_DrawText, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_qrcode(self, text, x=None, y=None, width=None, height=None, eccLevel=None, qrcPixels=None,
                    horizontalAlignment=None, verticalAlignment=None, orientation=None, **kwargs):
        """
        绘制二维码

        :param x: 绘制对象的水平坐标位置，单位毫米。
        :param y: 绘制对象的垂直坐标位置，单位毫米。
        :param width: 绘制对象的显示宽度，单位毫米。
                    值默认为0，表示根据 {@link qrcPixels} 设定的点的大小自动计算二维码大小。
        :param height: 绘制对象的显示高度，不指定表示按照：{@link width} 来显示，单位毫米。
        :param eccLevel: 二维码纠错模式，值参考{@link LPA_QREccLevel}，默认为{@link LPA_QREccLevel.EccLevel_L}。
        :param qrcPixels: 表示在不指定二维码显示宽度的情况下，二维码每个逻辑点的像素个数，默认为2个像素。
        :param horizontalAlignment: 对象显示水平对齐方式，在指定了宽度的情况下有效。
        :param verticalAlignment: 对象显示垂直对齐方式，在指定了高度的情况下生效。
        :param orientation: 设置绘制对象的旋转角度，值为0、90、180、270。默认为0，表示不做任何旋转处理。
        :param kwargs: 关键字参数：
        {
            textEncoding 字符串编码方式，值参考{@link LPA_QRTextEncoding}，默认为{@link LPA_QRTextEncoding.UTF8}。
            qrcVersion 二维码编码最小版本号，1~40，默认为根据内容自动计算。
            encodeMode 二维码编码模式，值参考{@link LPA_QREncodeMode}，默认为{@link LPA_QREncodeMode.Numeric}。
        }  其他二维码相关参数
        """

        options = utils.get_request_data(locals())
        options = utils.convert_of_base(options)
        #
        resp = self.request_api(utils.ACTION_Draw2DQRCode, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_barcode(self, text, x=None, y=None, width=None, height=None, textHeight=None, type=None,
                     fontName=None, fontStyle=None, textAlignment=None, barPixels=None, horizontalAlignment=None,
                     verticalAlignment=None, orientation=None, **kwargs):
        """
        绘制一维码

        :param text: 待绘制的一维码数据。
        :param x: 绘制对象的水平坐标位置，单位毫米。值默认为0。
        :param y: 绘制对象的垂直坐标位置，单位毫米。值默认为0。
        :param width: 绘制对象的显示宽度，单位毫米。 值默认为0，表示根据 {@link barWidth} 设定的点的大小自动计算对象宽度。
        :param height: 绘制对象的显示高度，单位毫米。值默认为0，表示根据 {@link barWidth} 设定的点的大小自动计算对象宽度。
        :param textHeight: 一维码中供人识读文本的高度，单位毫米，值默认为0，表示不显示一维码下面的字符串。
        :param type: 一维码类型，默认为{@link LPA_BarcodeType.LPA_1DBT_AUTO}，表示根据字符串自动采用最佳方式。
        :param fontName: 一维码中供人识读文本的字体名称，默认为{@link CONSTANTS.FONT_NAME}。
        :param fontStyle: 一维码供人识读文本的字体风格，默认为{@link LPA_FontStyle.Regular}，表示显示常规字体样式。
        :param textAlignment: 一维码供人识读文本的水平对齐方式，值参考{@link LPA_ItemAlignment}，
                            >= 5 表示表示跟随一维码本身的水平对齐方式，默认为{@link LPA_ItemAlignment.Center}，也即居中对齐。
        :param barPixels 在不指定一维码宽度的情况下，一维码中每个逻辑点的像素大小，单位像素，值为 1 - 7 之间的任意值，默认为2。
        :param horizontalAlignment: 对象显示水平对齐方式，在指定了宽度的情况下有效。
        :param verticalAlignment: 对象显示垂直对齐方式，在指定了高度的情况下生效。
        :param orientation: 设置绘制对象的旋转角度，值为0、90、180、270。默认为0，表示不做任何旋转处理。
        :param kwargs: 关键字参数：
        {
            barcodeFlags 一维码编码参数标志，值参考{@link LPA_BarcodeFlags}，默认为 ShowReadDown | ShowStartStop | EanCheckCode。
            textBarSpace 一维码供人识读文本和条码的垂直间距，单位毫米，默认为约2个像素。
        }
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_base(options)
        if "textHeight" in options:
            options["textHeight"] = utils.unit_convert(options["textHeight"])
        #
        resp = self.request_api(utils.ACTION_Draw1DBarcode, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_pdf417(self, text, x=None, y=None, width=None, height=None, eccLevel=None,
                    horizontalAlignment=None, verticalAlignment=None, orientation=None, **kwargs):
        """
        绘制PDF417二维码

        :param text: 待绘制的PDF417二维码数据。
        :param x: 绘制对象的水平坐标位置，单位毫米，值默认为0。
        :param y: 绘制对象的垂直坐标位置，单位毫米，值默认为0。
        :param width: 绘制对象的显示宽度，单位毫米，值默认为0，表示根据 {@link p417Pixels} 设置的大小自动计算二维码宽度。
        :param height: 绘制对象的显示高度，单位毫米
                        值默认为0，表示根据 {@link p417Pixels} 设置的大小自动计算二维码高度。
        :param eccLevel: 二维码纠错模式，值参考{@link LPA_P417EccLevel}，默认为{@link LPA_P417EccLevel.Auto}。
        :param horizontalAlignment: 对象显示水平对齐方式，在指定了宽度的情况下有效。
        :param verticalAlignment: 对象显示垂直对齐方式，在指定了高度的情况下生效。
        :param orientation: 设置绘制对象的旋转角度，值为0、90、180、270。默认为0，表示不做任何旋转处理。
        :param kwargs: 其他关键字参数：
        {
            textEncoding 字符串编码方式，{@link LPA_P417TextEncoding}，默认为{@link LPA_P417TextEncoding.UTF8}。
            p417Pixels 在不指定二维码宽度的情况下每个逻辑点的像素个数，默认为2。
            encodeMode 二维码编码模式，值参考{@link LPA_P417EncodeMode}，默认为{@link LPA_P417EncodeMode.Auto}。如果编码内容需要更高级别的编码模式，程序会自动升级模式。

        }
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_base(options)
        #
        resp = self.request_api(utils.ACTION_Draw2DPdf417, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_datamatrix(self, text, x, y, width, height):
        """
        绘制DataMatrix二维码
        :param text: 待绘制的PDF417二维码数据。
        :param x: 绘制对象的水平坐标位置，单位毫米，值默认为0。
        :param y: 绘制对象的垂直坐标位置，单位毫米，值默认为0。
        :param width: 绘制对象的显示宽度，单位毫米。
        :param height: 绘制对象的显示高度，单位毫米。
        :param horizontalAlignment: 对象显示水平对齐方式，在指定了宽度的情况下有效。
        :param verticalAlignment: 对象显示垂直对齐方式，在指定了高度的情况下生效。
        :param orientation: 设置绘制对象的旋转角度，值为0、90、180、270。默认为0，表示不做任何旋转处理。
        :param kwargs: 其他关键字参数：
        {
        }
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_base(options)
        #
        resp = self.request_api(utils.ACTION_DrawDataMatrix, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_image(self, imageFile, x=None, y=None, width=None, height=None, threshold=None, **kwargs):
        """
        绘制图像

        :param imageFile:
        :param x:
        :param y:
        :param width:
        :param height:
        :param threshold:
        :param kwargs:
        """
        options = utils.get_request_data(locals())
        if "data" in options:
            return self.draw_image_data(kwargs["data"], x, y, width, height, threshold, **kwargs)
        #
        options = utils.convert_of_base(options)
        #
        resp = self.request_api(utils.ACTION_DrawImage, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_image_data(self, data, x=None, y=None, drawWidth=None, drawHeight=None, threshold=None, orientation=None,
                        **kwargs):
        """
        绘制图像

        :param orientation:
        :param data:
        :param x:
        :param y:
        :param drawWidth:
        :param drawHeight:
        :param threshold:
        :param kwargs:
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_base(options)
        options["drawWidth"] = utils.unit_convert(options["drawWidth"])
        options["drawHeight"] = utils.unit_convert(options["drawHeight"])
        #
        resp = self.request_api(utils.ACTION_DrawImageD, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_rect(self, x=None, y=None, width=None, height=None, lineWidth=None, cornerWidth=None,
                  cornerHeight=None, fill=False, orientation=None, **kwargs):
        """
        绘制矩形

        :param x: 矩形的水平位置，单位毫米，值默认为0。
        :param y: 矩形的垂直位置，单位毫米，值默认为0。
        :param width: 矩形的水平宽度，单位毫米，0。
        :param height: 矩形的垂直高度，单位毫米，值默认与宽度一样。
        :param lineWidth: 圆角矩形的线宽，单位毫米，值默认为{@link LINE_WIDTH}。
        :param cornerWidth: 矩形的圆角宽度，单位毫米，值默认为{@link DEFAULT_RECT_WIDTH}。
        :param cornerHeight: 矩形的圆角高度，单位毫米，值默认为0。
        :param fill: 是否绘制填充圆角矩形，值默认为false，表示显示矩形边框。
        :param orientation: 旋转角度，0、90、180、270。默认为0，表示不旋转。
        :param kwargs:
        { }
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_round_rect(options)
        if options["cornerWidth"]:
            if options["fill"]:
                resp = self.request_api(
                    utils.ACTION_FillRoundRectangle, data=options)
            else:
                resp = self.request_api(
                    utils.ACTION_DrawRoundRectangle, data=options)
        else:
            if options["fill"]:
                resp = self.request_api(
                    utils.ACTION_FillRectangle, data=options)
            else:
                resp = self.request_api(
                    utils.ACTION_DrawRectangle, data=options)
        #
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_ellipse(self, x=None, y=None, width=None, height=None, lineWidth=None, fill=False, orientation=None,
                     **kwargs):
        """
        绘制椭圆

        :param x: 椭圆的水平位置，单位毫米，值默认为0。
        :param y: 椭圆的垂直位置，单位毫米，值默认为0。
        :param width: 椭圆的水平宽度，单位毫米，值默认为{@link DEFAULT_RECT_WIDTH}。
        :param height: 椭圆的垂直高度，单位毫米，值默认与宽度相同。
        :param lineWidth: 椭圆的线宽，单位毫米，值默认为{@link CONSTANTS.LINE_WIDTH}。
        :param fill: 是否绘制填充椭圆，默认为false，表示绘制椭圆边框。
        :param orientation: 旋转角度，0、90、180、270。默认为0，表示不旋转。
        :param kwargs: 其他关键字参数；
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_rect(options)
        #
        if options["fill"]:
            resp = self.request_api(utils.ACTION_FillEllipse, data=options)
        else:
            resp = self.request_api(utils.ACTION_DrawEllipse, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    def draw_circle(self, x=None, y=None, radius=None, lineWidth=None, fill=False, **kwargs):
        """
        绘制圆形
        :param x: 水平方向上的圆心坐标位置，单位毫米，值默认为0。
        :param y: 垂直方向上的圆心坐标位置，单位毫米，值默认为0。
        :param radius: 圆形半径，单位毫米，值默认为{@link DEFAULT_RADIUS}。
        :param lineWidth 圆形边框宽度，单位毫米，值默认为{@link DEFAULT_LINE_WIDTH}。
        :param fill: 是否绘制填充圆形，默认为false，表示只绘制圆形边框。
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_circle(options)
        if options["fill"]:
            resp = self.request_api(utils.ACTION_FillEllipse, data=options)
        else:
            resp = self.request_api(utils.ACTION_DrawEllipse, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK

    # def drawArc(x, y, radius, start=0, end=360, lineWidth=0, **kargs):
    #     """绘制弧线"""
    #     return self.request_api(draw_arc(x, y, radius, start=start, end=end, lineWidth=lineWidth, **kargs)

    def draw_line(self, x1=None, y1=None, x2=None, y2=None, lineWidth=None, dashLens=None, orientation=None, **kwargs):
        """
        绘制直线
        :param x1: 点划线起点，单位毫米，值默认为0。
        :param y1: 点划线起点，单位毫米，值默认为0。
        :param x2: 点划线终点，单位毫米，值默认为x1。
        :param y2: 点划线终点，单位毫米，值默认为y1。
        :param lineWidth: lineWidth: 直线线宽，单位毫米，值默认为{@link CONSTANTS.lineWidth}。
        :param dashLens: 点化线线段长度的数组。
        :param orientation: 旋转角度，0、90、180、270。默认为0，表示不旋转。
        :param kwargs:
        :return:
        """
        options = utils.get_request_data(locals())
        options = utils.convert_of_line(options)
        #
        if "dashLen" in options and options["dashLen"]:
            resp = self.request_api(utils.ACTION_DrawDashLine, data=options)
        else:
            resp = self.request_api(utils.ACTION_DrawLine, data=options)
        return resp[RESP_STATUS_CODE] == LPA_RESULT_OK


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    api = DTPWeb()
    # webapi.getPrinters("DP23 Label Printer")
    # webapi.isPrinterOpened()
    # webapi.drawText("hello", fontHeight=5)
    # printers = api.get_printers()
    # print(printers)
    api.check_port()
