<template>
    <view class="uni-container">
        <view class="uni-btn-v">
            <view class="uni-list">
                <label class="uni-list-cell uni-list-cell-pd">
                    <view class="uni-list-cell-db">开始/停止扫描</view>
                    <switch
                        :checked="isStarted"
                        @change="onStartStatusChanged"
                    ></switch>
                </label>
                <label class="uni-list-cell uni-list-cell-pd">
                    <view class="uni-list-cell-db">连续扫描</view>
                    <switch
                        :checked="isContinueOpened"
                        @change="onContinueOpenedChanged"
                    ></switch>
                </label>
                <label class="uni-list-cell uni-list-cell-pd">
                    <view class="uni-list-cell-db">震动</view>
                    <switch
                        :checked="isVibrateOpened"
                        @change="onVibrateOpenedChagned"
                    ></switch>
                </label>
                <label class="uni-list-cell uni-list-cell-pd">
                    <view class="uni-list-cell-db">声音</view>
                    <switch
                        :checked="isBeepOpened"
                        @change="onBeepOpenedChanged"
                    ></switch>
                </label>
                <view class="uni-list-cell uni-list-cell-pd">
                    <view class="uni-list-cell-left">字符串解码格式</view>
                    <view class="uni-list-cell-db">
                        <picker
                            @change="onDecodeModeChanged"
                            :value="index"
                            :range="textDecodeModes"
                        >
                            <view class="uni-input">{{
                                textDecodeModes[index]
                            }}</view>
                        </picker>
                    </view>
                </view>
            </view>
            <button type="primary" @click="onSetTimeout">
                配置扫描超时时间
            </button>
            <button type="primary" @click="onSetContinueInterval">
                配置连续扫描时间间隔
            </button>
        </view>
        <view>
            <!-- 输入框示例 -->
            <uni-popup ref="inputDialog" type="dialog">
                <uni-popup-dialog
                    ref="inputClose"
                    mode="input"
                    :title="inputDialog.title"
                    :value="inputDialog.value"
                    :placeholder="inputDialog.hint"
                    @confirm="onDialogInputConfirm"
                ></uni-popup-dialog>
            </uni-popup>
        </view>
    </view>
</template>

<script>
import api from "./dzscanner.js";
export default {
    data() {
        return {
            title: "Hello",
            textDecodeModes: [
                "Auto",
                "GB2312",
                "GBK",
                "GB18030",
                "UTF-8",
                "ISO-8859-1",
                "BIG5",
                "SJIS",
                "EUC-JP",
            ],
            index: 0,
            isStarted: false,
            isContinueOpened: false,
            isVibrateOpened: false,
            isBeepOpened: false,
            timeout: 5000,
            continueInterval: 1000,
            inputDialog: {
                title: "",
                hint: "",
                value: "",
                type: 0,
            },
        };
    },
    onLoad() {},
    methods: {
        onStartStatusChanged(e) {
            this.isStarted = e.detail.value;
            console.log(`isStarted = ${this.isStarted}`);
            if (this.isStarted) api.start();
            else api.close();
        },
        onContinueOpenedChanged(e) {
            this.isContinueOpened = e.detail.value;
            console.log(`isContinueOpened = ${this.isContinueOpened}`);
            //
            api.enableContinueScan(this.isContinueOpened);
        },
        onVibrateOpenedChagned(e) {
            this.isVibrateOpened = e.detail.value;
            console.log(`isVibrateOpened = ${this.isVibrateOpened}`);
            //
            api.enablePlayVibrate(this.isVibrateOpened);
        },
        onBeepOpenedChanged(e) {
            this.isBeepOpened = e.detail.value;
            console.log(`isBeepOpened = ${this.isBeepOpened}`);
            //
            api.enablePlayBeep(this.isBeepOpened);
        },
        onSetTimeout() {
            console.log("onSetTimeout");
            this.inputDialog.type = 1;
            this.inputDialog.title = "扫描超时时间";
            this.inputDialog.hint = "单位：毫秒";
            this.inputDialog.value = this.timeout;
            console.log(this.timeout);
            this.$refs.inputDialog.open();
        },
        onSetContinueInterval() {
            this.inputDialog.type = 2;
            this.inputDialog.title = "连续扫描间隔时间";
            this.inputDialog.hint = "单位：毫秒";
            this.inputDialog.value = this.continueInterval;
            this.$refs.inputDialog.open();
        },
        onDecodeModeChanged(e) {
            console.log(`onDecodeModeChanged, value = ${e.detail.value}`);
            this.index = e.detail.value;
            //
            // "Auto",
            // "GB2312",
            // "GBK",
            // "GB18030",
            // "UTF-8",
            // "ISO-8859-1",
            // "BIG5",
            // "SJIS",
            // "EUC-JP"
            if (this.index === 1) {
                api.setDecodeEncoding(api.DecodeEncodings.GB2312);
            } else if (this.index === 2) {
                api.setDecodeEncoding(api.DecodeEncodings.GBK);
            } else if (this.index === 3) {
                api.setDecodeEncoding(api.DecodeEncodings.GB18030);
            } else if (this.index === 4) {
                api.setDecodeEncoding(api.DecodeEncodings.UTF8);
            } else if (this.index === 5) {
                api.setDecodeEncoding(api.DecodeEncodings.ISO_8859_1);
            } else if (this.index === 6) {
                api.setDecodeEncoding(api.DecodeEncodings.BIG5);
            } else if (this.index === 7) {
                api.setDecodeEncoding(api.DecodeEncodings.SJIS);
            } else if (this.index === 8) {
                api.setDecodeEncoding(api.DecodeEncodings.EUC_JP);
            } else {
                api.setDecodeEncoding(api.DecodeEncodings.Auto);
            }
        },
        onDialogInputConfirm(val) {
            console.log(val);
            if (this.inputDialog.type === 1) {
                this.timeout = val;
                console.log(this.timeout);
                if (this.timeout >= 1000 && this.timeout <= 10000)
                    api.setTimeOut(this.timeout);
            } else if (this.inputDialog.type === 2) {
                this.continueInterval = val;
                if (
                    this.continueInterval >= 100 &&
                    this.continueInterval <= 3000
                )
                    api.setContinueInterval(this.continueInterval);
            }
            // 关闭窗口后，恢复默认内容
            this.$refs.inputDialog.close();
        },
    },
};
</script>

<style>
.uni-container {
    padding: 15px;
}
button {
    margin-top: 15px;
}
.content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.logo {
    height: 200rpx;
    width: 200rpx;
    margin-top: 200rpx;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 50rpx;
}

.text-area {
    display: flex;
    justify-content: center;
}

.title {
    font-size: 36rpx;
    color: #8f8f94;
}
</style>
