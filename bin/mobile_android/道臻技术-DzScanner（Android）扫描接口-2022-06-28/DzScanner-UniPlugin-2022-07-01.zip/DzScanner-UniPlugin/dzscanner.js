const api = uni.requireNativePlugin("DothanTech-DzScanner");

const ACTIONS = {
    open: "open",
    close: "close",
    start: "start",
    stop: "stop",
    setTimeOut: "setTimeOut",
    enableContinueScan: "enableContinueScan",
    setContinueInterval: "setContinueInterval",
    setDecodeEncoding: "setDecodeEncoding",
    enablePlayBeep: "enablePlayBeep",
    enablePlayVibrate: "enablePlayVibrate",
};
const RESULT_CODE = {
    OK: 0,
    PARAM_ERROR: 1,
    FAILED: 2,
};

function request(action, data, callback) {
    console.log(`### Request: action = ${action}`);
    console.log(data ? JSON.stringify(data) : data);
    return new Promise((resolve) => {
        if (api && api[action]) {
            api[action](data || {}, (result) => {
                console.log(`### Response:`);
                console.log(JSON.stringify(result));
                if (!result)
                    result = {
                        statusCode: -1,
                    };
                if (typeof callback === "function") {
                    callback(result.code === 0 ? result.data : null);
                }
                resolve(result);
            });
        } else {
            if (api) {
                resolve(undefined);
                console.log("DzScanner插件加载失败");
            } else {
                resolve(undefined);
                console.log("未检测到该方法:" + action);
            }
        }
    });
}

export default {
    /**
     * 打开扫描头，并设置扫描操作相关的回调，上电后才能进行扫描， 扫描前一定要先执行此操作再启动扫描。
     *
     * @return 返回结果。
     */
    async open() {
        const resp = await request(ACTIONS.open);
        return resp.statusCode === RESULT_CODE.OK ? resp.resultInfo : undefined;
    },

    /**
     * 关闭扫描头，关闭后扫描头停止工作，不再响应解码请求。
     * 该方法通常需要在{@code Activity}或者{@code Application}的{@code onDestory()}方法中调用。
     */
    async close() {
        const resp = await request(ACTIONS.close);
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 开始扫码， 调用后扫描头会出光并识别条码。
     */
    async start() {
        const resp = await request(ACTIONS.start);
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 停止扫描，此操作执行后，扫描头光会灭掉。
     */
    async stop() {
        const resp = await request(ACTIONS.stop);
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 配置扫描超时时间， 超过指定时间后自动停止扫描。
     *
     * @param timeout 扫描超时时间，时间单位： ms（毫秒），默认值：5000，取值范围：1000-10000。
     */
    async setTimeOut(timeout) {
        const resp = await request(ACTIONS.setTimeOut, {
            timeout: timeout,
        });
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 配置使能连续扫描。
     *
     * @param enableContinueScan 使能连续扫描？
     *                           true： 开启连续扫描， 说明： 设置打开连扫之后，需要点击扫描按键才能正常连扫。
     *                           false： 关闭连续扫描。
     */
    async enableContinueScan(enableContinueScan) {
        const resp = await request(ACTIONS.enableContinueScan, {
            enableContinueScan: enableContinueScan,
        });
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 配置连续扫描间隔时间， 连续扫描模式下，每次扫描成功后间隔时间。
     *
     * @param continueInterval 连扫间隔时间，时间单位：ms(毫秒)，默认值：1000，取值范围：100-3000。
     */
    async setContinueInterval(continueInterval) {
        const resp = await request(ACTIONS.setContinueInterval, {
            continueInterval: continueInterval,
        });
        return resp.statusCode === RESULT_CODE.OK;
    },
    DecodeEncodings: {
        GB2312: 21,
        GBK: 22,
        GB18030: 23,
        UTF8: 24,
        ISO_8859_1: 25,
        BIG5: 26,
        SJIS: 27,
        EUC_JP: 28,
        Auto: 100,
    },

    /**
     * 配置扫描解码字符编码格式。
     *
     * @param {number} decodeEncoding 解码字符编码格式，值参考{@link DecodeEncodings}。
     */
    async setDecodeEncoding(decodeEncoding) {
        const resp = await request(ACTIONS.setDecodeEncoding, {
            decodeEncoding: decodeEncoding,
        });
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 配置使能扫描成功后播放声音。
     *
     * @param {boolean} enablePlayBeep 使能播放声音？
     *                       true： 扫描成功后，播放声音
     *                       false：扫描成功后，不播放声音
     */
    async enablePlayBeep(enablePlayBeep) {
        const resp = await request(ACTIONS.enablePlayBeep, {
            enablePlayBeep: enablePlayBeep,
        });
        return resp.statusCode === RESULT_CODE.OK;
    },

    /**
     * 配置使能扫描成功后振动。
     *
     * @param {boolean}  enablePlayVibrate 使能振动？
     *                          true：扫描成功后， 振动提示
     *                          false：扫描成功后，不振动
     */
    async enablePlayVibrate(enablePlayVibrate) {
        const resp = await request(ACTIONS.enablePlayVibrate, {
            enablePlayVibrate: enablePlayVibrate,
        });
        return resp.statusCode === RESULT_CODE.OK;
    },
};
