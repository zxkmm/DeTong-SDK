# DzScanner-UniPlugin 使用文档

[![德佟电子](http://detonger.com/img/LOGO.png)](http://www.detonger.com)

## 联系方式

1. 官网：[德佟电子科技（上海）有限公司](http://www.detonger.com)

2. 电话：021-65111580

3. 邮箱：support@dothantech.com

4. 全国服务热线：400-823-6599

## 使用方式

在需要的地方引入插件配套的 js 接口，根据实际需求，调用对应的接口函数，完成相关操作；

1. 导入插件；
	将厂家提供的插件包解压缩后复制到项目的 **nativeplugins** 目录中；

2. 配置插件；
	用HBuilderX打开目标项目，选择manifest.json，打开配置视图，在右侧选择“App原生插件配置”，找到“本地插件”，点击“选择本地插件”，勾选 **dothantech-dzscanner**；

3. 再页面中导入封装的js接口；
	将接口包中提供的 **dzscanner.js** 复制到项目的指定地方，然后在代码中通过import 引入JavaScript接口，eg:

```javascript
	import api from './dzscanner.js';
```
4. 调用接口函数，进行相关扫描操作；
```js
	async openScanner() {
		const result = await api.open();
		console.log(result);
		if (result) {
			console.log("扫码器打开成功");
		} else {
			console.log("扫码器打开失败");
		}
	}
```
5. 编译自定义基座；
	调试模式下需要编译一个自定义基座才可以使用，本接口是原生插件，标准的基座是不加载原生插件的，所以要进行测试必须编译一个自定义基座才可以操作打印机；
	自定义基座编译方法：
	打开HBuilderX，选择菜单：运行-->运行到手机或模拟器-->制作自定义调试基座，根据实际情况选择相关选项，然后点击“打包”即可；

## 接口函数介绍

```js
interface OpenResult {
	// type: number;
	result: string;
	decodeTime: number;
}

public interface DzScanner {
	/**
     * 打开扫描头，并设置扫描操作相关的回调，上电后才能进行扫描， 扫描前一定要先执行此操作再启动扫描。
     *
     * @return {OpenResult}返回结果。
     */
    async open(): Promise<OpenResult|undefined>;

    /**
     * 关闭扫描头，关闭后扫描头停止工作，不再响应解码请求。
     * 该方法通常需要在{@code Activity}或者{@code Application}的{@code onDestory()}方法中调用。
     */
    async close(): Promise<boolean>;

    /**
     * 开始扫码， 调用后扫描头会出光并识别条码。
     */
    async start(): Promise<boolean>;

    /**
     * 停止扫描，此操作执行后，扫描头光会灭掉。
     */
    async stop(): Promise<boolean>;

    /**
     * 配置扫描超时时间， 超过指定时间后自动停止扫描。
     *
     * @param timeout 扫描超时时间，时间单位： ms（毫秒），默认值：5000，取值范围：1000-10000。
     */
    async setTimeOut(timeout): Promise<boolean>;

    /**
     * 配置使能连续扫描。
     *
     * @param enableContinueScan 使能连续扫描？
     *                           true： 开启连续扫描， 说明： 设置打开连扫之后，需要点击扫描按键才能正常连扫。
     *                           false： 关闭连续扫描。
     */
    async enableContinueScan(enableContinueScan): Promise<boolean>;

    /**
     * 配置连续扫描间隔时间， 连续扫描模式下，每次扫描成功后间隔时间。
     *
     * @param continueInterval 连扫间隔时间，时间单位：ms(毫秒)，默认值：1000，取值范围：100-3000。
     */
    async setContinueInterval(continueInterval): Promise<boolean>;
    DecodeEncodings: {
        GB2312: 21,
        GBK: 22,
        GB18030: 23,
        UTF8: 24,
        ISO_8859_1: 25,
        BIG5: 26,
        SJIS: 27,
        EUC_JP: 28,
        Auto: 100,
    };

    /**
     * 配置扫描解码字符编码格式。
     *
     * @param {number} decodeEncoding 解码字符编码格式，值参考{@link DecodeEncodings}。
     */
    async setDecodeEncoding(decodeEncoding): Promise<boolean>;

    /**
     * 配置使能扫描成功后播放声音。
     *
     * @param {boolean} enablePlayBeep 使能播放声音？
     *                       true： 扫描成功后，播放声音
     *                       false：扫描成功后，不播放声音
     */
    async enablePlayBeep(enablePlayBeep): Promise<boolean>;

    /**
     * 配置使能扫描成功后振动。
     *
     * @param {boolean}  enablePlayVibrate 使能振动？
     *                          true：扫描成功后， 振动提示
     *                          false：扫描成功后，不振动
     */
    async enablePlayVibrate(enablePlayVibrate): Promise<boolean>;
```
